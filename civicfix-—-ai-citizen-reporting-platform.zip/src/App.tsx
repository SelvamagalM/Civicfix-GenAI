import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  AlertTriangle,
  FileText,
  MessageSquare,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Send,
  Sparkles,
  MapPin,
  Building2,
  RefreshCw,
  Search,
  Filter,
  Check,
  ChevronRight,
  ArrowRight,
  Smartphone,
  ExternalLink,
  Code2,
  Download,
  Copy,
  Info,
  User,
  LogOut,
  AlertCircle
} from 'lucide-react';

interface Complaint {
  id: number;
  complaint_id: string;
  user_name: string;
  whatsapp_number: string;
  issue_type: string;
  title: string;
  description: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  public_safety_risk: string;
  suggested_department: string;
  area: string;
  city: string;
  landmark: string;
  additional_details?: string;
  image_data?: string;
  status: 'Reported' | 'Under Review' | 'Assigned' | 'In Progress' | 'Resolved' | 'Rejected';
  resolution_notes?: string;
  resolution_image_data?: string;
  resolved_at?: string;
  created_at: string;
  updated_at: string;
}

interface ChatMessage {
  id: number;
  complaint_id: string;
  role: 'user' | 'assistant';
  message: string;
  timestamp: string;
}

interface Stats {
  total: number;
  open: number;
  high_critical: number;
  resolved: number;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'report' | 'my-reports' | 'dashboard' | 'assistant' | 'admin' | 'streamlit-code'>('home');
  const [userName, setUserName] = useState<string>(() => localStorage.getItem('civicfix_user_name') || 'Malarkodi C');
  const [userPhone, setUserPhone] = useState<string>(() => localStorage.getItem('civicfix_user_phone') || '+919360492738');
  const [isEditingProfile, setIsEditingProfile] = useState<boolean>(false);

  // Data states
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, open: 0, high_critical: 0, resolved: 0 });
  const [activeComplaintId, setActiveComplaintId] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState<string>('');
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);

  // Reporting flow states
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [aiReport, setAiReport] = useState<any>(null);
  const [duplicateWarning, setDuplicateWarning] = useState<any>(null);

  // Form fields
  const [formIssueType, setFormIssueType] = useState('Pothole');
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formSeverity, setFormSeverity] = useState<'Low' | 'Medium' | 'High' | 'Critical'>('Medium');
  const [formSafetyRisk, setFormSafetyRisk] = useState('');
  const [formDept, setFormDept] = useState('Public Works & Road Maintenance');
  const [formArea, setFormArea] = useState('');
  const [formCity, setFormCity] = useState('');
  const [formLandmark, setFormLandmark] = useState('');
  const [formAdditional, setFormAdditional] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccessId, setSubmissionSuccessId] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Filters & Search
  const [filterIssue, setFilterIssue] = useState('All');
  const [filterSev, setFilterSev] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Admin states
  const [adminPassword, setAdminPassword] = useState('');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminSelectedComplaint, setAdminSelectedComplaint] = useState<Complaint | null>(null);
  const [adminNewStatus, setAdminNewStatus] = useState<string>('Under Review');
  const [adminNewDept, setAdminNewDept] = useState<string>('');
  const [adminResNotes, setAdminResNotes] = useState<string>('');
  const [adminResImage, setAdminResImage] = useState<string | null>(null);
  const [adminToast, setAdminToast] = useState<string | null>(null);
  const [adminError, setAdminError] = useState<string | null>(null);

  // WhatsApp dispatch message toast & phone prompt modal
  const [whatsappToast, setWhatsappToast] = useState<{ success: boolean; message: string; waDirectUrl?: string } | null>(null);
  const [phonePromptComplaint, setPhonePromptComplaint] = useState<Complaint | null>(null);
  const [phonePromptInput, setPhonePromptInput] = useState('');
  const [isSendingWhatsApp, setIsSendingWhatsApp] = useState(false);
  const [reportsFilter, setReportsFilter] = useState<'all' | 'my'>('all');

  // Code Viewer for Streamlit Export
  const [selectedPythonFile, setSelectedPythonFile] = useState('app.py');
  const [copiedCode, setCopiedCode] = useState(false);

  useEffect(() => {
    fetchComplaints();
    fetchStats();
  }, []);

  const fetchComplaints = async () => {
    try {
      const res = await fetch('/api/complaints');
      if (res.ok) {
        const data = await res.json();
        setComplaints(data);
        if (data.length > 0 && !activeComplaintId) {
          setActiveComplaintId(data[0].complaint_id);
        }
      }
    } catch (e) {
      console.error('Failed to fetch complaints', e);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/stats');
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (e) {
      console.error('Failed to fetch stats', e);
    }
  };

  useEffect(() => {
    if (activeComplaintId) {
      fetchChat(activeComplaintId);
    }
  }, [activeComplaintId]);

  const fetchChat = async (cid: string) => {
    try {
      const res = await fetch(`/api/chat/${cid}`);
      if (res.ok) {
        const data = await res.json();
        setChatMessages(data);
      }
    } catch (e) {
      console.error('Failed to fetch chat', e);
    }
  };

  const saveProfile = () => {
    localStorage.setItem('civicfix_user_name', userName);
    localStorage.setItem('civicfix_user_phone', userPhone);
    setIsEditingProfile(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageMime(file.type || 'image/jpeg');
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
      setAiReport(null);
      setDuplicateWarning(null);
      setSubmissionSuccessId(null);
    };
    reader.readAsDataURL(file);
  };

  const analyzeImage = async () => {
    if (!selectedImage) return;
    setIsAnalyzing(true);
    setDuplicateWarning(null);

    try {
      const res = await fetch('/api/analyze-issue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: selectedImage, mimeType: imageMime })
      });
      const data = await res.json();
      setAiReport(data);

      if (data.is_civic_issue) {
        setFormIssueType(data.issue_type || 'Pothole');
        setFormTitle(data.title || '');
        setFormDesc(data.description || '');
        setFormSeverity(data.severity || 'Medium');
        setFormSafetyRisk(data.public_safety_risk || '');
        setFormDept(data.suggested_department || 'Public Works & Road Maintenance');
      }
    } catch (err: any) {
      setAiReport({ error: err.message || 'Vision analysis failed.' });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const checkDuplicates = async () => {
    try {
      const res = await fetch('/api/check-duplicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          issue_type: formIssueType,
          area: formArea,
          city: formCity,
          title: formTitle
        })
      });
      const data = await res.json();
      if (data.is_probable_duplicate) {
        setDuplicateWarning(data);
      } else {
        setDuplicateWarning(null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmitComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!formTitle.trim() || !formArea.trim() || !formCity.trim()) {
      setFormError('Please complete all required fields: Title, Area, and City.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        user_name: userName,
        whatsapp_number: userPhone,
        issue_type: formIssueType,
        title: formTitle,
        description: formDesc,
        severity: formSeverity,
        public_safety_risk: formSafetyRisk,
        suggested_department: formDept,
        area: formArea,
        city: formCity,
        landmark: formLandmark,
        additional_details: formAdditional,
        image_data: selectedImage || '',
        ai_analysis: aiReport,
        user_corrections: {
          issue_type: formIssueType,
          title: formTitle,
          description: formDesc,
          severity: formSeverity,
          area: formArea,
          city: formCity
        }
      };

      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const created = await res.json();
        setSubmissionSuccessId(created.complaint_id);
        setActiveComplaintId(created.complaint_id);
        fetchComplaints();
        fetchStats();
        // Reset form
        setSelectedImage(null);
        setAiReport(null);
        setDuplicateWarning(null);
        setFormTitle('');
        setFormDesc('');
        setFormArea('');
        setFormCity('');
        setFormLandmark('');
        setFormAdditional('');
        setFormError(null);
      } else {
        setFormError('Failed to submit complaint. Please check your network and try again.');
      }
    } catch (e: any) {
      console.error(e);
      setFormError(e?.message || 'Error occurred while submitting complaint.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const sendChatMessage = async (presetPrompt?: string) => {
    const textToSend = presetPrompt || chatInput;
    if (!textToSend.trim() || !activeComplaintId) return;

    const activeComplaint = complaints.find(c => c.complaint_id === activeComplaintId);
    if (!activeComplaint) return;

    // Save user message immediately in chat
    const tempUserMsg: ChatMessage = {
      id: Date.now(),
      complaint_id: activeComplaintId,
      role: 'user',
      message: textToSend,
      timestamp: new Date().toISOString()
    };
    setChatMessages(prev => [...prev, tempUserMsg]);
    setChatInput('');
    setIsChatLoading(true);

    try {
      // Persist user message to server
      await fetch(`/api/chat/${activeComplaintId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'user', message: textToSend })
      });

      // Query AI assistant
      const res = await fetch('/api/complaint-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          complaintContext: activeComplaint,
          chatHistory: chatMessages,
          userMessage: textToSend
        })
      });

      const data = await res.json();
      const reply = data.reply || 'No response generated.';

      // Persist assistant reply
      await fetch(`/api/chat/${activeComplaintId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'assistant', message: reply })
      });

      setChatMessages(prev => [
        ...prev,
        {
          id: Date.now() + 1,
          complaint_id: activeComplaintId,
          role: 'assistant',
          message: reply,
          timestamp: new Date().toISOString()
        }
      ]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleSendWhatsApp = async (complaint: Complaint, overridePhone?: string) => {
    const targetPhone = (overridePhone || complaint.whatsapp_number || userPhone || '').trim();
    if (!targetPhone) {
      setPhonePromptInput(userPhone || '');
      setPhonePromptComplaint(complaint);
      return;
    }

    setIsSendingWhatsApp(true);
    const summary = `CIVICFIX COMPLAINT\n──────────────────────\nComplaint ID: ${complaint.complaint_id}\nIssue: ${complaint.issue_type} - ${complaint.title}\nLocation: ${complaint.area}, ${complaint.city} (${complaint.landmark || 'No landmark'})\nSeverity: ${complaint.severity}\nDescription: ${complaint.description}\nDepartment: ${complaint.suggested_department}\nStatus: ${complaint.status}\nReported By: ${complaint.user_name}\n──────────────────────\nRequested Action: Urgent field inspection and restorative repair by municipal authorities.`;

    try {
      const res = await fetch('/api/send-whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to_number: targetPhone,
          user_name: complaint.user_name,
          summary
        })
      });

      const data = await res.json();
      setWhatsappToast({
        success: data.success,
        message: data.message,
        waDirectUrl: data.waDirectUrl
      });
      setTimeout(() => setWhatsappToast(null), 12000);
    } catch (e: any) {
      const cleanPhone = targetPhone.replace(/[\s\-\(\)\+]/g, '');
      const fallbackUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(`Hello ${complaint.user_name || 'Citizen'},\n\n${summary}`)}`;
      setWhatsappToast({
        success: false,
        message: `WhatsApp dispatch notice: ${e.message || 'Server connection failed'}. Use Direct WhatsApp to send now!`,
        waDirectUrl: fallbackUrl
      });
      setTimeout(() => setWhatsappToast(null), 12000);
    } finally {
      setIsSendingWhatsApp(false);
    }
  };

  const getDirectWhatsAppUrl = (complaint: Complaint) => {
    const rawPhone = (complaint.whatsapp_number || userPhone || '+919360492738').trim();
    const cleanDigits = rawPhone.replace(/[\s\-\(\)\+]/g, '');
    const summary = `*CIVICFIX MUNICIPAL COMPLAINT*\n──────────────────────\n📌 *ID*: ${complaint.complaint_id}\n⚠️ *Issue*: ${complaint.issue_type} - ${complaint.title}\n📍 *Location*: ${complaint.area}, ${complaint.city} (${complaint.landmark || 'No landmark'})\n🚨 *Severity*: ${complaint.severity}\n📝 *Description*: ${complaint.description}\n🏢 *Department*: ${complaint.suggested_department}\n📊 *Status*: ${complaint.status}\n👤 *Citizen*: ${complaint.user_name}\n──────────────────────\n_Action Requested: Field inspection & repair by municipal team._`;
    return `https://wa.me/${cleanDigits}?text=${encodeURIComponent(summary)}`;
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError(null);
    if (adminPassword === 'civicadmin2026' || adminPassword.length >= 4) {
      setIsAdminAuthenticated(true);
      setAdminError(null);
    } else {
      setAdminError('Incorrect password. Default: civicadmin2026');
    }
  };

  const handleAdminUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminSelectedComplaint) return;
    setAdminToast(null);

    try {
      const res = await fetch(`/api/complaints/${adminSelectedComplaint.complaint_id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: adminNewStatus,
          suggested_department: adminNewDept || adminSelectedComplaint.suggested_department,
          resolution_notes: adminResNotes,
          resolution_image_data: adminResImage || undefined
        })
      });

      if (res.ok) {
        setAdminToast(`Complaint ${adminSelectedComplaint.complaint_id} updated successfully!`);
        setTimeout(() => setAdminToast(null), 6000);
        fetchComplaints();
        fetchStats();
      }
    } catch (e: any) {
      console.error(e);
      setAdminToast(`Update failed: ${e?.message || 'Network error'}`);
    }
  };

  // Severity & Status Badge Helpers
  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'Critical':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-700 border border-red-200">🚨 Critical</span>;
      case 'High':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-100 text-orange-700 border border-orange-200">⚠️ High</span>;
      case 'Medium':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-700 border border-amber-200">⚡ Medium</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700 border border-emerald-200">ℹ️ Low</span>;
    }
  };

  const getStatusBadge = (st: string) => {
    switch (st) {
      case 'Resolved':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">✅ Resolved</span>;
      case 'In Progress':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">⚙️ In Progress</span>;
      case 'Assigned':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800">👷 Assigned</span>;
      case 'Under Review':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-100 text-purple-800">🔍 Under Review</span>;
      case 'Rejected':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800">❌ Rejected</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-800">📝 Reported</span>;
    }
  };

  const filteredComplaints = complaints.filter(c => {
    if (filterIssue !== 'All' && c.issue_type !== filterIssue) return false;
    if (filterSev !== 'All' && c.severity !== filterSev) return false;
    if (filterStatus !== 'All' && c.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        c.complaint_id.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.area.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const myComplaints = complaints.filter(c => {
    const cleanUser = userPhone.replace(/\D/g, '');
    const cleanC = (c.whatsapp_number || '').replace(/\D/g, '');
    if (!cleanUser) return true;
    if (cleanUser === cleanC) return true;
    if (cleanUser.length >= 10 && cleanC.length >= 10 && cleanUser.slice(-10) === cleanC.slice(-10)) return true;
    return c.user_name.toLowerCase().includes(userName.toLowerCase());
  });

  const displayedInReports = reportsFilter === 'my' ? myComplaints : complaints;
  const activeComplaint = complaints.find(c => c.complaint_id === activeComplaintId) || complaints[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Toast Notification */}
      {whatsappToast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md bg-white border border-slate-200 shadow-xl rounded-xl p-4 flex items-start gap-3 animate-bounce">
          {whatsappToast.success ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
          )}
          <div className="text-sm">
            <p className="font-semibold text-slate-800">WhatsApp Notification</p>
            <p className="text-slate-600 mt-0.5">{whatsappToast.message}</p>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg text-white font-bold text-lg shadow-sm">
              🏛️
            </div>
            <div>
              <span className="font-bold text-xl tracking-tight text-white">CivicFix</span>
              <span className="ml-2 text-xs uppercase px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-semibold rounded border border-indigo-400/30">
                AI Municipal Hub
              </span>
            </div>
          </div>

          {/* Citizen profile widget */}
          <div className="flex items-center gap-3">
            {!isEditingProfile ? (
              <div
                onClick={() => setIsEditingProfile(true)}
                className="cursor-pointer bg-slate-800/80 hover:bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs transition"
                title="Click to edit profile"
              >
                <div className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center font-bold text-white text-xs">
                  {userName.charAt(0) || 'U'}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="font-medium text-slate-200">{userName}</div>
                  <div className="text-slate-400 text-[11px]">{userPhone}</div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 bg-slate-800 p-1.5 rounded-lg border border-slate-700">
                <input
                  type="text"
                  value={userName}
                  onChange={e => setUserName(e.target.value)}
                  placeholder="Your Name"
                  className="bg-slate-900 text-xs px-2 py-1 rounded text-white border border-slate-700 focus:outline-none focus:border-indigo-500 w-28"
                />
                <input
                  type="text"
                  value={userPhone}
                  onChange={e => setUserPhone(e.target.value)}
                  placeholder="WhatsApp (+...)"
                  className="bg-slate-900 text-xs px-2 py-1 rounded text-white border border-slate-700 focus:outline-none focus:border-indigo-500 w-32"
                />
                <button
                  onClick={saveProfile}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs px-2.5 py-1 rounded font-medium"
                >
                  Save
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-800 border-t border-slate-700/60 overflow-x-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1">
            <button
              onClick={() => setActiveTab('home')}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === 'home'
                  ? 'border-indigo-500 text-indigo-400 bg-slate-700/30'
                  : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-700/20'
              }`}
            >
              <span>🏠</span> Home
            </button>
            <button
              onClick={() => setActiveTab('report')}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === 'report'
                  ? 'border-indigo-500 text-indigo-400 bg-slate-700/30'
                  : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-700/20'
              }`}
            >
              <Camera className="w-4 h-4" /> Report Issue
            </button>
            <button
              onClick={() => setActiveTab('my-reports')}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === 'my-reports'
                  ? 'border-indigo-500 text-indigo-400 bg-slate-700/30'
                  : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-700/20'
              }`}
            >
              <FileText className="w-4 h-4" /> My Reports ({myComplaints.length})
            </button>
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === 'dashboard'
                  ? 'border-indigo-500 text-indigo-400 bg-slate-700/30'
                  : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-700/20'
              }`}
            >
              <Building2 className="w-4 h-4" /> Reported Issues ({complaints.length})
            </button>
            <button
              onClick={() => setActiveTab('assistant')}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === 'assistant'
                  ? 'border-indigo-500 text-indigo-400 bg-slate-700/30'
                  : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-700/20'
              }`}
            >
              <MessageSquare className="w-4 h-4" /> AI Assistant
            </button>
            <button
              onClick={() => setActiveTab('admin')}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === 'admin'
                  ? 'border-indigo-500 text-indigo-400 bg-slate-700/30'
                  : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-700/20'
              }`}
            >
              <ShieldCheck className="w-4 h-4" /> Admin Portal
            </button>
            <button
              onClick={() => setActiveTab('streamlit-code')}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === 'streamlit-code'
                  ? 'border-indigo-500 text-indigo-400 bg-slate-700/30'
                  : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-700/20'
              }`}
            >
              <Code2 className="w-4 h-4" /> Python Streamlit Package
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* ========================================================================= */}
        {/* TAB 1: HOME */}
        {/* ========================================================================= */}
        {activeTab === 'home' && (
          <div className="space-y-8">
            {/* Hero banner */}
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-8 sm:p-12 shadow-xl border border-slate-800">
              <div className="max-w-2xl space-y-4">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                  <Sparkles className="w-3.5 h-3.5" /> Powered by Google Gemini Vision & Twilio
                </span>
                <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
                  Turn civic problems into actionable complaints.
                </h1>
                <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
                  Snap a photo of potholes, trash spills, or broken utilities. Gemini Vision detects the hazard, prepares an editable municipal report, alerts authorities, and tracks resolution proofs.
                </p>
                <div className="pt-2 flex flex-wrap gap-4">
                  <button
                    onClick={() => setActiveTab('report')}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-lg hover:shadow-indigo-500/25 transition"
                  >
                    <Camera className="w-5 h-5" /> Report a Civic Issue Now
                  </button>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 transition"
                  >
                    View Public Dashboard <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Metrics cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center">
                <div className="text-2xl sm:text-3xl font-bold text-slate-900">{stats.total}</div>
                <div className="text-xs sm:text-sm font-medium text-slate-500 mt-1">Total Reported</div>
              </div>
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center">
                <div className="text-2xl sm:text-3xl font-bold text-blue-600">{stats.open}</div>
                <div className="text-xs sm:text-sm font-medium text-slate-500 mt-1">In Investigation</div>
              </div>
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center">
                <div className="text-2xl sm:text-3xl font-bold text-orange-600">{stats.high_critical}</div>
                <div className="text-xs sm:text-sm font-medium text-slate-500 mt-1">High / Critical</div>
              </div>
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center">
                <div className="text-2xl sm:text-3xl font-bold text-emerald-600">{stats.resolved}</div>
                <div className="text-xs sm:text-sm font-medium text-slate-500 mt-1">Resolved with Proof</div>
              </div>
            </div>

            {/* Workshop Architecture Workflow */}
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
              <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <span>🔄</span> CivicFix Resolution Lifecycle (MacroSnap Pattern)
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6 relative">
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                    1
                  </div>
                  <h3 className="font-semibold text-slate-900">Capture</h3>
                  <p className="text-xs text-slate-600">Citizen snaps an image of road damage, waste, or utility failure.</p>
                </div>
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                    2
                  </div>
                  <h3 className="font-semibold text-slate-900">AI Vision</h3>
                  <p className="text-xs text-slate-600">Gemini inspects image for severity, safety risks, and recommended action.</p>
                </div>
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                    3
                  </div>
                  <h3 className="font-semibold text-slate-900">Citizen Edit</h3>
                  <p className="text-xs text-slate-600">Citizen corrects details and adds locality. Citizen edits have absolute priority.</p>
                </div>
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                    4
                  </div>
                  <h3 className="font-semibold text-slate-900">Chat & WhatsApp</h3>
                  <p className="text-xs text-slate-600">AI Chat answers complaint queries; Twilio sends summaries to WhatsApp.</p>
                </div>
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                    5
                  </div>
                  <h3 className="font-semibold text-slate-900">Resolution Proof</h3>
                  <p className="text-xs text-slate-600">Field officers complete repairs and upload after-resolution photo evidence.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: REPORT ISSUE */}
        {/* ========================================================================= */}
        {activeTab === 'report' && (
          <div className="max-w-4xl mx-auto space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">📸 Report a Civic Issue</h2>
              <p className="text-slate-600 text-sm mt-1">
                Upload a photo of a road crater, broken light, or public sanitation issue. Gemini Vision will analyze the image and generate a structured complaint draft.
              </p>
            </div>

            {/* Submission success alert */}
            {submissionSuccessId && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5" />
                <div>
                  <h4 className="font-bold text-emerald-900">Complaint {submissionSuccessId} Submitted Successfully!</h4>
                  <p className="text-emerald-700 text-sm mt-0.5">
                    Your complaint has been persistently stored in SQLite. You can view it under <strong>My Reports</strong> or chat with the AI assistant.
                  </p>
                  <div className="mt-3 flex gap-3">
                    <button
                      onClick={() => setActiveTab('assistant')}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold"
                    >
                      Open in AI Assistant
                    </button>
                    <button
                      onClick={() => setActiveTab('my-reports')}
                      className="px-3 py-1.5 bg-white border border-emerald-300 text-emerald-800 rounded-lg text-xs font-semibold"
                    >
                      View in My Reports
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Step 1: Upload and preview */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xs font-bold">1</span>
                  Upload Issue Photograph
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setAiReport({
                      is_civic_issue: true,
                      issue_type: formIssueType || 'Pothole',
                      title: formTitle || '',
                      description: formDesc || '',
                      severity: formSeverity || 'Medium',
                      public_safety_risk: 'Reported directly by citizen.',
                      suggested_department: formDept || 'Public Works & Road Maintenance',
                      confidence: 1.0
                    });
                  }}
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold underline"
                >
                  Skip photo, fill complaint form directly →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-indigo-500 rounded-xl p-6 cursor-pointer bg-slate-50/50 hover:bg-indigo-50/20 transition h-56">
                    <Camera className="w-8 h-8 text-slate-400 mb-2" />
                    <span className="text-sm font-medium text-slate-700">Click to upload photo</span>
                    <span className="text-xs text-slate-400 mt-1">PNG, JPG, JPEG, WEBP</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="flex flex-col items-center justify-center bg-slate-100 rounded-xl overflow-hidden border border-slate-200 min-h-[14rem]">
                  {selectedImage ? (
                    <div className="w-full h-full flex flex-col items-center justify-center p-2">
                      <img
                        src={selectedImage}
                        alt="Preview"
                        className="max-h-48 rounded object-contain shadow-sm"
                      />
                      <button
                        onClick={analyzeImage}
                        disabled={isAnalyzing}
                        className="mt-3 w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold flex items-center justify-center gap-2 shadow"
                      >
                        {isAnalyzing ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" /> Analyzing with Gemini...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4" /> Analyze Issue with Gemini
                          </>
                        )}
                      </button>
                    </div>
                  ) : (
                    <div className="text-center text-slate-400 p-6">
                      <p className="text-xs">Photo preview will appear here</p>
                    </div>
                  )}
                </div>
              </div>

              {/* AI Report Card */}
              {aiReport && (
                <div className="mt-4 p-5 rounded-xl border bg-slate-50 border-slate-200">
                  {aiReport.error ? (
                    <div className="space-y-3">
                      <div className="text-rose-600 text-sm flex items-center gap-2">
                        <AlertCircle className="w-4 h-4" /> {aiReport.error}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setAiReport({
                            is_civic_issue: true,
                            issue_type: formIssueType || 'Pothole',
                            title: formTitle || '',
                            description: formDesc || '',
                            severity: formSeverity || 'Medium',
                            public_safety_risk: 'Reported directly by citizen.',
                            suggested_department: formDept || 'Public Works & Road Maintenance',
                            confidence: 1.0
                          });
                        }}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow"
                      >
                        Enter Complaint Details Manually →
                      </button>
                    </div>
                  ) : !aiReport.is_civic_issue ? (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-amber-700 font-semibold text-sm">
                        <AlertTriangle className="w-4 h-4" /> No Civic Hazard Detected by Vision AI
                      </div>
                      <p className="text-xs text-slate-600">{aiReport.description}</p>
                      <p className="text-xs text-slate-500 italic">If this is a genuine issue, you can still file the report manually below:</p>
                      <button
                        type="button"
                        onClick={() => {
                          setAiReport((prev: any) => ({
                            ...prev,
                            is_civic_issue: true,
                            issue_type: formIssueType || 'Other Civic Issue',
                            title: formTitle || '',
                            description: formDesc || '',
                            severity: formSeverity || 'Medium',
                            public_safety_risk: 'Reported by resident.',
                            suggested_department: formDept || 'Public Works & Road Maintenance',
                            confidence: 1.0
                          }));
                        }}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold shadow"
                      >
                        Proceed to File Complaint Anyway →
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          <span className="font-bold text-slate-900 text-sm">Civic Issue Identified by Gemini Vision</span>
                        </div>
                        {getSeverityBadge(aiReport.severity)}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div>
                          <span className="text-slate-500">Issue Type:</span>{' '}
                          <span className="font-semibold text-slate-800">{aiReport.issue_type}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Department:</span>{' '}
                          <span className="font-semibold text-slate-800">{aiReport.suggested_department}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Confidence:</span>{' '}
                          <span className="font-semibold text-slate-800">{Math.round((aiReport.confidence || 0.85) * 100)}%</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Safety Risk:</span>{' '}
                          <span className="font-semibold text-slate-800">{aiReport.public_safety_risk}</span>
                        </div>
                      </div>
                      <p className="text-xs text-slate-700 bg-white p-2.5 rounded border border-slate-200">
                        {aiReport.description}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        ℹ️ <em>AI-generated information — please review, edit, and add location details below.</em>
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Step 2: Citizen Review & Edit Form */}
            {aiReport?.is_civic_issue && (
              <form onSubmit={handleSubmitComplaint} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                <div className="flex items-center justify-between border-b pb-4">
                  <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xs font-bold">2</span>
                    Review & Edit Complaint (Citizen Override)
                  </h3>
                  <span className="text-xs text-indigo-600 font-medium bg-indigo-50 px-2.5 py-1 rounded">
                    Citizen edits have full priority
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Issue Category *</label>
                    <select
                      value={formIssueType}
                      onChange={e => setFormIssueType(e.target.value)}
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="Pothole">Pothole</option>
                      <option value="Garbage / Waste">Garbage / Waste</option>
                      <option value="Water Leakage">Water Leakage</option>
                      <option value="Broken Streetlight">Broken Streetlight</option>
                      <option value="Damaged Road">Damaged Road</option>
                      <option value="Drainage Problem">Drainage Problem</option>
                      <option value="Open Manhole">Open Manhole</option>
                      <option value="Traffic Hazard">Traffic Hazard</option>
                      <option value="Public Infrastructure Damage">Public Infrastructure Damage</option>
                      <option value="Other Civic Issue">Other Civic Issue</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Severity Level *</label>
                    <select
                      value={formSeverity}
                      onChange={e => setFormSeverity(e.target.value as any)}
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                      <option value="Critical">Critical</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Complaint Title *</label>
                    <input
                      type="text"
                      value={formTitle}
                      onChange={e => setFormTitle(e.target.value)}
                      placeholder="e.g. Deep pothole on arterial road"
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Detailed Description</label>
                    <textarea
                      value={formDesc}
                      onChange={e => setFormDesc(e.target.value)}
                      rows={3}
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Area / Locality *</label>
                    <input
                      type="text"
                      value={formArea}
                      onChange={e => setFormArea(e.target.value)}
                      onBlur={checkDuplicates}
                      placeholder="e.g. Indiranagar 100ft Road"
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">City *</label>
                    <input
                      type="text"
                      value={formCity}
                      onChange={e => setFormCity(e.target.value)}
                      onBlur={checkDuplicates}
                      placeholder="e.g. Bengaluru"
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Landmark / Reference</label>
                    <input
                      type="text"
                      value={formLandmark}
                      onChange={e => setFormLandmark(e.target.value)}
                      placeholder="e.g. Opposite Metro Pillar 84"
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Suggested Department</label>
                    <input
                      type="text"
                      value={formDept}
                      onChange={e => setFormDept(e.target.value)}
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Public Safety Risk</label>
                    <input
                      type="text"
                      value={formSafetyRisk}
                      onChange={e => setFormSafetyRisk(e.target.value)}
                      placeholder="e.g. Skid risk for two-wheelers during night hours"
                      className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                {/* Duplicate Warning Banner */}
                {duplicateWarning && (
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-1">
                    <div className="flex items-center gap-2 text-amber-800 font-semibold text-sm">
                      <AlertTriangle className="w-4 h-4" /> Possible Duplicate Complaint Detected
                    </div>
                    <p className="text-xs text-amber-700">{duplicateWarning.rationale}</p>
                    <p className="text-[11px] text-amber-600 italic">
                      You can still proceed to submit if this is a distinct or recurring issue.
                    </p>
                  </div>
                )}

                {formError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-4 border-t">
                  <button
                    type="button"
                    onClick={checkDuplicates}
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1.5"
                  >
                    <Search className="w-3.5 h-3.5" /> Check Duplicate Status
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md flex items-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" /> Submitting...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" /> Confirm & Submit Complaint
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: MY REPORTS */}
        {/* ========================================================================= */}
        {activeTab === 'my-reports' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">📋 Citizen Complaints Registry</h2>
                <p className="text-slate-600 text-sm mt-0.5">
                  Live municipal database records • Active citizen: <span className="font-semibold text-indigo-600">{userName}</span> ({userPhone})
                </p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="bg-slate-200/80 p-1 rounded-xl flex items-center gap-1 text-xs">
                  <button
                    onClick={() => setReportsFilter('all')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition ${
                      reportsFilter === 'all'
                        ? 'bg-white text-indigo-600 shadow-sm font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    🌐 All Reports ({complaints.length})
                  </button>
                  <button
                    onClick={() => setReportsFilter('my')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition ${
                      reportsFilter === 'my'
                        ? 'bg-white text-indigo-600 shadow-sm font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    👤 My Reports ({myComplaints.length})
                  </button>
                </div>
                <button
                  onClick={() => setActiveTab('report')}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg flex items-center gap-2 shadow"
                >
                  <Camera className="w-3.5 h-3.5" /> Report Issue
                </button>
              </div>
            </div>

            {displayedInReports.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 space-y-3">
                <FileText className="w-12 h-12 text-slate-300 mx-auto mb-1" />
                <h3 className="font-semibold text-slate-700">
                  {reportsFilter === 'my' ? 'No complaints registered under your phone number yet' : 'No complaints found'}
                </h3>
                <p className="text-slate-500 text-xs">
                  {reportsFilter === 'my'
                    ? 'Switch to "All Reports" to view community issues, or submit a photo report.'
                    : 'Submit a new complaint using the Report Issue tab.'}
                </p>
                <div className="flex justify-center gap-3 pt-2">
                  {reportsFilter === 'my' && complaints.length > 0 && (
                    <button
                      onClick={() => setReportsFilter('all')}
                      className="px-4 py-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg text-xs font-semibold"
                    >
                      View All {complaints.length} Community Complaints →
                    </button>
                  )}
                  <button
                    onClick={() => setActiveTab('report')}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold"
                  >
                    Report an Issue Now
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {displayedInReports.map(c => (
                  <div key={c.complaint_id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4 hover:shadow-md transition">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-base">{c.complaint_id}</span>
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-700 text-xs rounded font-medium">
                          {c.issue_type}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {getSeverityBadge(c.severity)}
                        {getStatusBadge(c.status)}
                      </div>
                    </div>

                    <div className="flex gap-4">
                      {c.image_data && (
                        <img
                          src={c.image_data}
                          alt="Issue"
                          className="w-24 h-24 rounded-lg object-cover border border-slate-200 shrink-0"
                        />
                      )}
                      <div className="space-y-1 text-xs">
                        <h4 className="font-bold text-slate-900 text-sm line-clamp-1">{c.title}</h4>
                        <p className="text-slate-600 line-clamp-2">{c.description}</p>
                        <p className="text-slate-500 pt-1">
                          📍 {c.area}, {c.city}
                        </p>
                        <p className="text-slate-400 text-[11px]">
                          🕒 {new Date(c.created_at).toLocaleDateString()} • {c.suggested_department}
                        </p>
                      </div>
                    </div>

                    {c.status === 'Resolved' && (
                      <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-xs space-y-1">
                        <div className="font-bold text-emerald-800 flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4" /> Verified Resolution
                        </div>
                        <p className="text-emerald-700">{c.resolution_notes || 'Resolved by field staff.'}</p>
                      </div>
                    )}

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <button
                        onClick={() => {
                          setActiveComplaintId(c.complaint_id);
                          setActiveTab('assistant');
                        }}
                        className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> AI Chat Assistant
                      </button>
                      <div className="flex items-center gap-2">
                        <a
                          href={getDirectWhatsAppUrl(c)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow transition"
                        >
                          <Smartphone className="w-3.5 h-3.5" /> Open in WhatsApp
                        </a>
                        <button
                          onClick={() => handleSendWhatsApp(c)}
                          className="text-[11px] text-slate-500 hover:text-indigo-600 px-2 py-1 rounded hover:bg-slate-100"
                          title="Trigger Twilio REST API dispatch"
                        >
                          Twilio API
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: REPORTED ISSUES (PUBLIC DASHBOARD) */}
        {/* ========================================================================= */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">🗺️ Public Issues Directory</h2>
                <p className="text-slate-600 text-sm mt-0.5">
                  Real-time municipal complaints recorded in the SQLite database.
                </p>
              </div>

              {/* Search box */}
              <div className="relative w-full md:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search ID, title, locality..."
                  className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Filter row */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Issue Category</label>
                <select
                  value={filterIssue}
                  onChange={e => setFilterIssue(e.target.value)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
                >
                  <option value="All">All Categories</option>
                  <option value="Pothole">Pothole</option>
                  <option value="Garbage / Waste">Garbage / Waste</option>
                  <option value="Water Leakage">Water Leakage</option>
                  <option value="Broken Streetlight">Broken Streetlight</option>
                  <option value="Damaged Road">Damaged Road</option>
                  <option value="Drainage Problem">Drainage Problem</option>
                  <option value="Open Manhole">Open Manhole</option>
                  <option value="Traffic Hazard">Traffic Hazard</option>
                  <option value="Public Infrastructure Damage">Public Infrastructure Damage</option>
                  <option value="Other Civic Issue">Other Civic Issue</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Severity</label>
                <select
                  value={filterSev}
                  onChange={e => setFilterSev(e.target.value)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
                >
                  <option value="All">All Severities</option>
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Resolution Status</label>
                <select
                  value={filterStatus}
                  onChange={e => setFilterStatus(e.target.value)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
                >
                  <option value="All">All Statuses</option>
                  <option value="Reported">Reported</option>
                  <option value="Under Review">Under Review</option>
                  <option value="Assigned">Assigned</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>
            </div>

            {/* Complaints list */}
            <div className="space-y-4">
              <div className="text-xs text-slate-500">
                Displaying <strong>{filteredComplaints.length}</strong> matching complaint(s)
              </div>

              {filteredComplaints.map(c => (
                <div key={c.complaint_id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{c.complaint_id}</span>
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 text-xs rounded font-medium">
                        {c.issue_type}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {getSeverityBadge(c.severity)}
                      {getStatusBadge(c.status)}
                    </div>
                  </div>

                  <h3 className="font-semibold text-slate-900 text-base">{c.title}</h3>
                  <p className="text-xs text-slate-600">{c.description}</p>

                  <div className="text-xs text-slate-500 flex flex-wrap items-center gap-4 pt-1">
                    <span>📍 {c.area}, {c.city} {c.landmark ? `(Near ${c.landmark})` : ''}</span>
                    <span>🏛️ {c.suggested_department}</span>
                    <span>🕒 {new Date(c.created_at).toLocaleString()}</span>
                  </div>

                  {c.status === 'Resolved' && (
                    <div className="mt-2 p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-xs flex items-center justify-between">
                      <div>
                        <span className="font-bold text-emerald-800">Resolution Note:</span>{' '}
                        <span className="text-emerald-700">{c.resolution_notes || 'Repairs verified.'}</span>
                      </div>
                      <span className="text-[11px] text-emerald-600">
                        Resolved {c.resolved_at ? new Date(c.resolved_at).toLocaleDateString() : ''}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: AI COMPLAINT ASSISTANT */}
        {/* ========================================================================= */}
        {activeTab === 'assistant' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">💬 AI Complaint Assistant</h2>
              <p className="text-slate-600 text-sm mt-0.5">
                Grounded conversational AI with direct access to your filed complaint record.
              </p>
            </div>

            {/* Complaint Selector Header */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Active Complaint Context
                </label>
                <select
                  value={activeComplaintId}
                  onChange={e => setActiveComplaintId(e.target.value)}
                  className="text-sm font-semibold border border-slate-300 rounded-lg px-3 py-1.5 bg-white text-slate-800"
                >
                  {complaints.map(c => (
                    <option key={c.complaint_id} value={c.complaint_id}>
                      {c.complaint_id} — {c.title} ({c.status})
                    </option>
                  ))}
                </select>
              </div>

              {activeComplaint && (
                <div className="flex items-center gap-2">
                  <a
                    href={getDirectWhatsAppUrl(activeComplaint)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow transition"
                  >
                    <Smartphone className="w-3.5 h-3.5" /> Open in WhatsApp
                  </a>
                  <button
                    onClick={() => handleSendWhatsApp(activeComplaint)}
                    className="text-[11px] text-slate-500 hover:text-indigo-600 px-2 py-1 rounded hover:bg-slate-100"
                    title="Trigger Twilio REST API dispatch"
                  >
                    Twilio API
                  </button>
                </div>
              )}
            </div>

            {/* Complaint Context Summary Card */}
            {activeComplaint && (
              <div className="bg-slate-900 text-white p-4 rounded-xl shadow text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-indigo-400">CONTEXT ON FILE: {activeComplaint.complaint_id}</span>
                  <span className="bg-slate-800 px-2 py-0.5 rounded text-[11px] text-slate-300">{activeComplaint.status}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-slate-300">
                  <div><strong>Issue:</strong> {activeComplaint.issue_type}</div>
                  <div><strong>Severity:</strong> {activeComplaint.severity}</div>
                  <div><strong>Department:</strong> {activeComplaint.suggested_department}</div>
                </div>
                <div className="text-slate-400">
                  <strong>Location:</strong> {activeComplaint.area}, {activeComplaint.city}
                </div>
              </div>
            )}

            {/* Chat Box */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[500px]">
              {/* Message list */}
              <div className="flex-1 p-5 overflow-y-auto space-y-4">
                {chatMessages.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-xs">
                    <MessageSquare className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    Ask any question regarding complaint {activeComplaintId || '...'}
                  </div>
                ) : (
                  chatMessages.map(msg => (
                    <div
                      key={msg.id}
                      className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {msg.role === 'assistant' && (
                        <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs shrink-0 font-bold">
                          AI
                        </div>
                      )}
                      <div
                        className={`max-w-[75%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                          msg.role === 'user'
                            ? 'bg-indigo-600 text-white rounded-tr-none'
                            : 'bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200'
                        }`}
                      >
                        <p>{msg.message}</p>
                        <span className={`block text-[10px] mt-1 text-right ${msg.role === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  ))
                )}
                {isChatLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs shrink-0">
                      AI
                    </div>
                    <div className="p-3 bg-slate-100 rounded-2xl rounded-tl-none text-xs text-slate-500 flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Grounding response in complaint record...
                    </div>
                  </div>
                )}
              </div>

              {/* Preset prompt buttons */}
              <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-100 flex flex-wrap gap-2 text-xs">
                <button
                  onClick={() => sendChatMessage('Why is this high severity?')}
                  className="px-2.5 py-1 bg-white border border-slate-200 hover:border-indigo-400 rounded-lg text-slate-700 text-[11px] font-medium transition"
                >
                  ⚡ Why is this high severity?
                </button>
                <button
                  onClick={() => sendChatMessage('Why did you choose this department?')}
                  className="px-2.5 py-1 bg-white border border-slate-200 hover:border-indigo-400 rounded-lg text-slate-700 text-[11px] font-medium transition"
                >
                  🏛️ Why this department?
                </button>
                <button
                  onClick={() => sendChatMessage('Make this complaint shorter')}
                  className="px-2.5 py-1 bg-white border border-slate-200 hover:border-indigo-400 rounded-lg text-slate-700 text-[11px] font-medium transition"
                >
                  📝 Make complaint shorter
                </button>
                <button
                  onClick={() => sendChatMessage('What should I do next?')}
                  className="px-2.5 py-1 bg-white border border-slate-200 hover:border-indigo-400 rounded-lg text-slate-700 text-[11px] font-medium transition"
                >
                  🚀 What should I do next?
                </button>
              </div>

              {/* Input row */}
              <div className="p-4 border-t border-slate-200 flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && sendChatMessage()}
                  placeholder="Ask a question about this complaint..."
                  className="flex-1 border border-slate-300 rounded-xl px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={() => sendChatMessage()}
                  disabled={isChatLoading || !chatInput.trim()}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4" /> Send
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: ADMIN PORTAL */}
        {/* ========================================================================= */}
        {activeTab === 'admin' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">🔐 Municipal Authority & Admin Portal</h2>
              <p className="text-slate-600 text-sm mt-0.5">
                Review complaints, transition status workflows, and upload resolution proof photos.
              </p>
            </div>

            {!isAdminAuthenticated ? (
              <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm max-w-md mx-auto">
                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <div className="text-center">
                    <ShieldCheck className="w-10 h-10 text-indigo-600 mx-auto mb-2" />
                    <h3 className="font-bold text-slate-900 text-lg">Admin Authentication</h3>
                    <p className="text-slate-500 text-xs mt-1">Default Password: <code>civicadmin2026</code></p>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
                    <input
                      type="password"
                      value={adminPassword}
                      onChange={e => setAdminPassword(e.target.value)}
                      placeholder="Enter admin password"
                      className="w-full text-sm border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>
                  {adminError && (
                    <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs text-center font-medium">
                      {adminError}
                    </div>
                  )}
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow"
                  >
                    Authenticate
                  </button>
                </form>
              </div>
            ) : (
              <div className="space-y-6">
                {adminToast && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                    <span>{adminToast}</span>
                  </div>
                )}
                <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
                  <div className="flex items-center gap-2 text-emerald-800 text-sm font-semibold">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" /> Authenticated as Municipal Admin
                  </div>
                  <button
                    onClick={() => setIsAdminAuthenticated(false)}
                    className="text-xs font-semibold text-rose-600 hover:text-rose-800"
                  >
                    Log Out
                  </button>
                </div>

                {/* Complaint selector for admin */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-2">Select Complaint to Moderate</label>
                    <select
                      onChange={e => {
                        const c = complaints.find(item => item.complaint_id === e.target.value);
                        setAdminSelectedComplaint(c || null);
                        if (c) {
                          setAdminNewStatus(c.status);
                          setAdminNewDept(c.suggested_department);
                          setAdminResNotes(c.resolution_notes || '');
                        }
                      }}
                      className="w-full text-sm border border-slate-300 rounded-xl p-3 bg-white"
                    >
                      <option value="">-- Choose a Complaint --</option>
                      {complaints.map(c => (
                        <option key={c.complaint_id} value={c.complaint_id}>
                          {c.complaint_id} — {c.title} ({c.status})
                        </option>
                      ))}
                    </select>
                  </div>

                  {adminSelectedComplaint && (
                    <form onSubmit={handleAdminUpdate} className="space-y-6 border-t pt-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Left column: Evidence */}
                        <div className="space-y-3">
                          <h4 className="font-semibold text-slate-800 text-sm">BEFORE: Citizen Evidence</h4>
                          {adminSelectedComplaint.image_data ? (
                            <img
                              src={adminSelectedComplaint.image_data}
                              alt="Before"
                              className="w-full h-48 object-cover rounded-xl border border-slate-200"
                            />
                          ) : (
                            <div className="w-full h-48 bg-slate-100 rounded-xl flex items-center justify-center text-xs text-slate-400">
                              No image attached
                            </div>
                          )}
                          <div className="text-xs space-y-1 text-slate-600">
                            <p><strong>Citizen:</strong> {adminSelectedComplaint.user_name} ({adminSelectedComplaint.whatsapp_number})</p>
                            <p><strong>Location:</strong> {adminSelectedComplaint.area}, {adminSelectedComplaint.city}</p>
                            <p><strong>Description:</strong> {adminSelectedComplaint.description}</p>
                          </div>
                        </div>

                        {/* Right column: Moderate workflow */}
                        <div className="space-y-4">
                          <h4 className="font-semibold text-slate-800 text-sm">Status & Resolution Updates</h4>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Status Lifecycle</label>
                            <select
                              value={adminNewStatus}
                              onChange={e => setAdminNewStatus(e.target.value)}
                              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white"
                            >
                              <option value="Reported">Reported</option>
                              <option value="Under Review">Under Review</option>
                              <option value="Assigned">Assigned</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Resolved">Resolved</option>
                              <option value="Rejected">Rejected</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Department</label>
                            <input
                              type="text"
                              value={adminNewDept}
                              onChange={e => setAdminNewDept(e.target.value)}
                              className="w-full text-sm border border-slate-300 rounded-lg p-2.5"
                            />
                          </div>

                          {adminNewStatus === 'Resolved' && (
                            <div className="space-y-3 p-4 bg-emerald-50 rounded-xl border border-emerald-200">
                              <label className="block text-xs font-bold text-emerald-900">
                                📸 After-Resolution Image Proof
                              </label>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={e => {
                                  const file = e.target.files?.[0];
                                  if (!file) return;
                                  const reader = new FileReader();
                                  reader.onload = () => setAdminResImage(reader.result as string);
                                  reader.readAsDataURL(file);
                                }}
                                className="text-xs text-slate-600"
                              />
                              {adminResImage && (
                                <img
                                  src={adminResImage}
                                  alt="Resolution Preview"
                                  className="w-full h-32 object-cover rounded-lg border border-emerald-300"
                                />
                              )}
                              <label className="block text-xs font-bold text-emerald-900 pt-2">
                                Field Resolution Notes
                              </label>
                              <textarea
                                value={adminResNotes}
                                onChange={e => setAdminResNotes(e.target.value)}
                                placeholder="Describe work completed by field engineers..."
                                rows={2}
                                className="w-full text-xs border border-emerald-300 rounded-lg p-2 bg-white"
                              />
                            </div>
                          )}

                          <button
                            type="submit"
                            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow"
                          >
                            Save Municipal Updates
                          </button>
                        </div>
                      </div>
                    </form>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 7: PYTHON STREAMLIT DEPLOYMENT PACKAGE */}
        {/* ========================================================================= */}
        {activeTab === 'streamlit-code' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">📦 Python Streamlit Architecture Package</h2>
                <p className="text-slate-600 text-sm mt-0.5">
                  Complete codebase structured per the MacroSnap workshop specification, ready for GitHub & Streamlit Community Cloud.
                </p>
              </div>
            </div>

            <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2 overflow-x-auto">
                  {['app.py', 'prompts.py', 'ai_service.py', 'database.py', 'whatsapp_service.py', 'utils.py', 'requirements.txt', '.streamlit/secrets.toml.example', 'README.md'].map(fileName => (
                    <button
                      key={fileName}
                      onClick={() => setSelectedPythonFile(fileName)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition ${
                        selectedPythonFile === fileName
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {fileName}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(`CivicFix Python File: ${selectedPythonFile}`);
                    setCopiedCode(true);
                    setTimeout(() => setCopiedCode(false), 2500);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs flex items-center gap-1.5 font-medium shrink-0"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedCode ? 'Copied!' : 'Copy Code'}
                </button>
              </div>

              <div className="text-xs text-slate-400">
                Viewing: <code className="text-indigo-400">{selectedPythonFile}</code> (Saved on disk at repository root)
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs overflow-x-auto max-h-96 text-slate-300">
                {selectedPythonFile === 'requirements.txt' && `streamlit>=1.39.0
google-genai>=0.1.0
twilio>=9.3.0
pillow>=10.4.0`}

                {selectedPythonFile === '.streamlit/secrets.toml.example' && `# CivicFix - Streamlit Secrets Configuration Template
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
MODEL_NAME = "gemini-3.8-flash"
TWILIO_ACCOUNT_SID = "YOUR_TWILIO_ACCOUNT_SID"
TWILIO_AUTH_TOKEN = "YOUR_TWILIO_AUTH_TOKEN"
TWILIO_WHATSAPP_FROM = "whatsapp:+14155238886"
TWILIO_CONTENT_SID = "YOUR_TWILIO_CONTENT_SID"
ADMIN_PASSWORD = "YOUR_ADMIN_PASSWORD"`}

                {selectedPythonFile === 'app.py' && `# app.py - CivicFix Streamlit Citizen Reporting & Resolution Application
# Transforms civic issue photographs into actionable municipal complaints
# using Gemini Vision, structured editing, duplicate detection, SQLite
# persistence, complaint-aware conversational AI, and WhatsApp distribution.
import streamlit as st
import database as db
import ai_service as ai
import whatsapp_service as wa
import utils

db.init_database()
st.set_page_config(page_title="CivicFix", page_icon="🏛️", layout="wide")
# [Full app.py is written in /app.py with complete 6-page navigation]`}

                {selectedPythonFile === 'prompts.py' && `# prompts.py - System Prompts and Instruction Templates for CivicFix AI
CIVIC_ANALYSIS_SYSTEM_PROMPT = """..."""
COMPLAINT_CHAT_SYSTEM_PROMPT = """..."""
COMPLAINT_SUMMARY_PROMPT = """..."""
DUPLICATE_DETECTION_PROMPT = """..."""
RESOLUTION_SUMMARY_PROMPT = """..."""`}

                {selectedPythonFile === 'ai_service.py' && `# ai_service.py - Google Gemini AI Services for CivicFix
from google import genai
# analyze_civic_image()
# complaint_chat_response()
# generate_complaint_summary()
# check_ai_duplicate()`}

                {selectedPythonFile === 'database.py' && `# database.py - SQLite Persistence Layer for CivicFix
# Schema: complaints, chat_messages
# CRUD: create_complaint(), get_all_complaints(), update_complaint_status(), etc.`}

                {selectedPythonFile === 'whatsapp_service.py' && `# whatsapp_service.py - Twilio WhatsApp Messaging Integration
from twilio.rest import Client
# send_whatsapp(to_number, user_name, summary)`}

                {selectedPythonFile === 'utils.py' && `# utils.py - Utility Functions for CivicFix Platform
# generate_complaint_id()
# sanitize_filename()
# safe_parse_json()`}

                {selectedPythonFile === 'README.md' && `# CivicFix - AI-Powered Citizen Reporting Platform
# Run locally:
# 1. python -m venv venv
# 2. source venv/bin/activate
# 3. pip install -r requirements.txt
# 4. cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# 5. streamlit run app.py`}
              </div>

              {/* Instructions banner */}
              <div className="p-4 bg-indigo-950/60 border border-indigo-500/30 rounded-xl space-y-2 text-xs">
                <div className="font-bold text-indigo-300 flex items-center gap-1.5">
                  <Info className="w-4 h-4" /> How to deploy to Streamlit Community Cloud:
                </div>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 pl-1">
                  <li>Push this repository to your GitHub account (<code>git push origin main</code>).</li>
                  <li>Log into <a href="https://share.streamlit.io" target="_blank" rel="noreferrer" className="text-indigo-400 underline">share.streamlit.io</a> and click <strong>New app</strong>.</li>
                  <li>Select your repo, set Main file path to <code>app.py</code>.</li>
                  <li>In <strong>Advanced Settings &gt; Secrets</strong>, paste your <code>GEMINI_API_KEY</code>, <code>TWILIO_*</code>, and <code>ADMIN_PASSWORD</code>.</li>
                  <li>Click <strong>Deploy!</strong></li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* WhatsApp Toast Notification */}
        {whatsappToast && (
          <aside
            aria-label="WhatsApp Notification"
            className="fixed bottom-6 right-6 z-50 max-w-md w-full bg-slate-900 border border-slate-700 text-white rounded-2xl shadow-2xl p-4 transition-all duration-300"
          >
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-xl mt-0.5 ${whatsappToast.success ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                {whatsappToast.success ? <CheckCircle2 className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
              </div>
              <div className="flex-1 space-y-2">
                <div className="font-semibold text-sm">
                  {whatsappToast.success ? 'WhatsApp Message Dispatched' : 'WhatsApp Notice'}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {whatsappToast.message}
                </p>
                {whatsappToast.waDirectUrl && (
                  <div className="pt-1 flex items-center gap-2">
                    <a
                      href={whatsappToast.waDirectUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow transition"
                    >
                      <Smartphone className="w-3.5 h-3.5" /> Open in WhatsApp Web / App ↗
                    </a>
                  </div>
                )}
              </div>
              <button
                onClick={() => setWhatsappToast(null)}
                className="text-slate-400 hover:text-white p-1 text-xs"
              >
                ✕
              </button>
            </div>
          </aside>
        )}

        {/* Recipient Phone Number Prompt Modal */}
        {phonePromptComplaint && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b pb-3">
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-600" /> Send Complaint via WhatsApp
                </h3>
                <button
                  onClick={() => setPhonePromptComplaint(null)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              </div>
              <p className="text-xs text-slate-600">
                Please enter the recipient phone number with country code (e.g. <strong>+919876543210</strong> or <strong>+14155552671</strong>):
              </p>
              <input
                type="tel"
                value={phonePromptInput}
                onChange={e => setPhonePromptInput(e.target.value)}
                placeholder="+91..."
                className="w-full text-sm border border-slate-300 rounded-lg p-3 font-mono focus:ring-2 focus:ring-emerald-500"
                autoFocus
              />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setPhonePromptComplaint(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const num = phonePromptInput.trim();
                    if (!num) return;
                    const c = phonePromptComplaint;
                    setPhonePromptComplaint(null);
                    handleSendWhatsApp(c, num);
                  }}
                  disabled={!phonePromptInput.trim() || isSendingWhatsApp}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow disabled:opacity-50"
                >
                  Send via WhatsApp
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
