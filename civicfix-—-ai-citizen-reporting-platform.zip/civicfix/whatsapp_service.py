"""
whatsapp_service.py - Twilio WhatsApp Messaging Integration
============================================================
Follows the Twilio WhatsApp architecture from the MacroSnap workshop.
Gracefully handles missing credentials, validates recipients,
and transmits standardized complaint summaries.
"""

import os
import re
from typing import Tuple, Optional, Any

try:
    import streamlit as st
    HAS_STREAMLIT = True
except ImportError:
    HAS_STREAMLIT = False


def _get_secret(key: str, default: str = "") -> str:
    """Retrieve secret from Streamlit secrets, OS environment, or local config files."""
    if HAS_STREAMLIT:
        try:
            if key in st.secrets:
                return str(st.secrets[key])
        except Exception:
            pass

    val = os.environ.get(key)
    if val:
        return val

    # Fallback: check .streamlit/secrets.toml or .env
    for candidate in [".streamlit/secrets.toml", ".env"]:
        if os.path.exists(candidate):
            try:
                with open(candidate, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith(f"{key}") and "=" in line:
                            parts = line.split("=", 1)
                            if parts[0].strip() == key:
                                return parts[1].strip().strip('"\'')
            except Exception:
                pass

    return default


def get_twilio_credentials() -> dict:
    """Return dictionary of Twilio WhatsApp credentials."""
    return {
        "account_sid": _get_secret("TWILIO_ACCOUNT_SID"),
        "auth_token": _get_secret("TWILIO_AUTH_TOKEN"),
        "whatsapp_from": _get_secret("TWILIO_WHATSAPP_FROM"),
        "content_sid": _get_secret("TWILIO_CONTENT_SID", "")
    }


def is_twilio_configured() -> bool:
    """Check if all minimum required Twilio secrets are present."""
    creds = get_twilio_credentials()
    return bool(creds["account_sid"] and creds["auth_token"] and creds["whatsapp_from"])


def get_twilio_client():
    """Create and return authenticated Twilio REST Client."""
    creds = get_twilio_credentials()
    if not (creds["account_sid"] and creds["auth_token"]):
        return None

    try:
        from twilio.rest import Client
        return Client(creds["account_sid"], creds["auth_token"])
    except ImportError:
        print("Twilio package not installed. Install via `pip install twilio`.")
        return None
    except Exception as e:
        print(f"Error initializing Twilio client: {e}")
        return None


def format_whatsapp_recipient(number: str) -> str:
    """Ensure recipient number conforms to WhatsApp E.164 specification (whatsapp:+...)."""
    clean = re.sub(r'[\s\-\(\)]', '', number.strip())
    if not clean.startswith('+'):
        # If no country code prefix, default to standard international '+'
        clean = '+' + clean
    if not clean.startswith('whatsapp:'):
        clean = f"whatsapp:{clean}"
    return clean


def send_whatsapp(
    to_number: str,
    user_name: str,
    summary: str
) -> Tuple[bool, str]:
    """
    Send formatted complaint summary via Twilio WhatsApp API.
    
    Returns:
        (success: bool, message: str)
    """
    if not is_twilio_configured():
        return (
            False,
            "WhatsApp integration is not configured yet. Add Twilio credentials in Streamlit secrets."
        )

    creds = get_twilio_credentials()
    client = get_twilio_client()

    if not client:
        return (
            False,
            "Unable to initialize Twilio client. Please verify TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN."
        )

    from_number = creds["whatsapp_from"]
    if not from_number.startswith("whatsapp:"):
        from_number = f"whatsapp:{from_number}"

    to_whatsapp = format_whatsapp_recipient(to_number)

    try:
        # If an approved Twilio Content Template SID is supplied, use content_sid
        content_sid = creds.get("content_sid")
        if content_sid:
            try:
                import json
                message = client.messages.create(
                    content_sid=content_sid,
                    from_=from_number,
                    to=to_whatsapp,
                    content_variables=json.dumps({"1": user_name, "2": summary[:900]})
                )
                return True, f"WhatsApp message queued successfully! Message SID: {message.sid}"
            except Exception as template_err:
                print(f"Content template failed, falling back to direct body: {template_err}")

        # Standard direct body message
        personalized_body = f"Hello {user_name},\nHere is your official CivicFix complaint update:\n\n{summary}"
        message = client.messages.create(
            body=personalized_body,
            from_=from_number,
            to=to_whatsapp
        )
        return True, f"WhatsApp message sent successfully! Message SID: {message.sid}"

    except Exception as e:
        error_msg = str(e)
        return False, f"Twilio WhatsApp dispatch failed: {error_msg}"
