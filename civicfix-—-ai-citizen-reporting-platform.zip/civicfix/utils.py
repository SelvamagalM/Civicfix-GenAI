"""
utils.py - Utility Functions for CivicFix Platform
===================================================
Provides complaint ID generation, file persistence helpers,
safe JSON parsing, data validation, and formatting tools.
"""

import os
import re
import json
import uuid
import datetime
from typing import Dict, Any, Optional, Tuple


def generate_complaint_id(prefix: str = "CF", count_offset: int = 1) -> str:
    """
    Generate a dynamic, standardized civic complaint ID.
    Example: CF-2026-0001, CF-2026-0042
    """
    current_year = datetime.datetime.now().year
    padded_num = f"{count_offset:04d}"
    return f"{prefix}-{current_year}-{padded_num}"


def sanitize_filename(filename: str) -> str:
    """Sanitize uploaded file names to prevent path traversal."""
    base = os.path.basename(filename)
    clean_name = re.sub(r'[^a-zA-Z0-9_\-\.]', '_', base)
    return f"{uuid.uuid4().hex[:8]}_{clean_name}"


def safe_parse_json(text: str) -> Dict[str, Any]:
    """
    Robust JSON parser for Gemini LLM outputs.
    Handles Markdown code blocks, preamble text, or raw JSON.
    """
    if not text or not isinstance(text, str):
        return {}

    cleaned = text.strip()

    # Look for ```json ... ``` or ``` ... ```
    json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', cleaned, re.IGNORECASE)
    if json_match:
        cleaned = json_match.group(1).strip()

    # Try standard parse
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Find first '{' and last '}'
    first_brace = cleaned.find('{')
    last_brace = cleaned.rfind('}')
    if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
        snippet = cleaned[first_brace:last_brace + 1]
        try:
            return json.loads(snippet)
        except json.JSONDecodeError:
            pass

    return {}


def format_timestamp(ts: Optional[str]) -> str:
    """Format an ISO timestamp or date string into human-readable format."""
    if not ts:
        return "N/A"
    try:
        # Handle 'YYYY-MM-DDTHH:MM:SS' or 'YYYY-MM-DD HH:MM:SS'
        clean_ts = ts.replace("T", " ")
        dt = datetime.datetime.fromisoformat(clean_ts.split(".")[0])
        return dt.strftime("%b %d, %Y • %I:%M %p")
    except Exception:
        return ts


def validate_complaint_input(
    title: str,
    issue_type: str,
    area: str,
    city: str
) -> Tuple[bool, str]:
    """Validate mandatory fields for civic complaint submission."""
    if not title or len(title.strip()) < 3:
        return False, "Title must be at least 3 characters long."
    if not issue_type or issue_type.strip() == "":
        return False, "Please select an Issue Type."
    if not area or len(area.strip()) < 2:
        return False, "Please enter the Area/Locality."
    if not city or len(city.strip()) < 2:
        return False, "Please enter the City."
    return True, ""


def validate_whatsapp_number(number: str) -> bool:
    """Validate international or national phone number format."""
    if not number:
        return False
    clean = re.sub(r'[\s\-\(\)\+]', '', number)
    return len(clean) >= 8 and clean.isdigit()


def get_severity_badge(severity: str) -> Dict[str, str]:
    """Return styling parameters (color, icon) for severity levels."""
    sev = (severity or "Medium").capitalize()
    if sev == "Critical":
        return {"color": "red", "hex": "#EF4444", "bg": "#FEE2E2", "icon": "🚨"}
    elif sev == "High":
        return {"color": "orange", "hex": "#F97316", "bg": "#FFEDD5", "icon": "⚠️"}
    elif sev == "Medium":
        return {"color": "yellow", "hex": "#EAB308", "bg": "#FEF9C3", "icon": "⚡"}
    else:
        return {"color": "green", "hex": "#10B981", "bg": "#D1FAE5", "icon": "ℹ️"}


def get_status_badge(status: str) -> Dict[str, str]:
    """Return styling parameters (color, icon) for complaint status."""
    st = (status or "Reported").title()
    mapping = {
        "Reported": {"color": "blue", "hex": "#3B82F6", "bg": "#DBEAFE", "icon": "📝"},
        "Under Review": {"color": "purple", "hex": "#8B5CF6", "bg": "#EDE9FE", "icon": "🔍"},
        "Assigned": {"color": "indigo", "hex": "#6366F1", "bg": "#E0E7FF", "icon": "👷"},
        "In Progress": {"color": "amber", "hex": "#F59E0B", "bg": "#FEF3C7", "icon": "⚙️"},
        "Resolved": {"color": "emerald", "hex": "#10B981", "bg": "#D1FAE5", "icon": "✅"},
        "Rejected": {"color": "rose", "hex": "#F43F5E", "bg": "#FFE4E6", "icon": "❌"}
    }
    return mapping.get(st, {"color": "gray", "hex": "#6B7280", "bg": "#F3F4F6", "icon": "📌"})
