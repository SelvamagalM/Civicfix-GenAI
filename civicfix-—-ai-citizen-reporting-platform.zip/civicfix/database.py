"""
database.py - SQLite Persistence Layer for CivicFix
===================================================
Manages persistent storage for complaints, status workflows,
resolution proofs, chat histories, and duplicate detection indexing.
"""

import os
import sqlite3
import datetime
import json
from typing import Dict, List, Any, Optional, Tuple

DB_DIR = os.path.join(os.path.dirname(__file__), "data")
DEFAULT_DB_PATH = os.path.join(DB_DIR, "civicfix.db")


def get_db_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    """Get SQLite database connection with row factory enabled."""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_database(db_path: str = DEFAULT_DB_PATH) -> None:
    """Initialize SQLite schema if tables do not exist."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    # Complaints Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS complaints (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        complaint_id TEXT UNIQUE NOT NULL,
        user_name TEXT NOT NULL,
        whatsapp_number TEXT NOT NULL,
        issue_type TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        severity TEXT NOT NULL,
        public_safety_risk TEXT,
        suggested_department TEXT,
        area TEXT NOT NULL,
        city TEXT NOT NULL,
        landmark TEXT,
        additional_details TEXT,
        image_path TEXT,
        ai_analysis TEXT,
        user_corrections TEXT,
        status TEXT NOT NULL DEFAULT 'Reported',
        resolution_notes TEXT,
        resolution_image_path TEXT,
        resolved_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
    """)

    # Chat Messages Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        complaint_id TEXT NOT NULL,
        role TEXT NOT NULL,
        message TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (complaint_id) REFERENCES complaints (complaint_id)
    );
    """)

    # Indices for performance and duplicate detection
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_complaint_id ON complaints(complaint_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_complaint_user ON complaints(whatsapp_number);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_complaint_area_city ON complaints(city, area);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_chat_complaint ON chat_messages(complaint_id);")

    conn.commit()
    conn.close()


def get_next_complaint_offset(db_path: str = DEFAULT_DB_PATH) -> int:
    """Get the current count of complaints + 1 for sequential ID generation."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM complaints")
    count = cursor.fetchone()[0]
    conn.close()
    return count + 1


def create_complaint(data: Dict[str, Any], db_path: str = DEFAULT_DB_PATH) -> str:
    """Insert a new citizen complaint into SQLite."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    now = datetime.datetime.now().isoformat()
    ai_json = json.dumps(data.get("ai_analysis", {}))
    corrections_json = json.dumps(data.get("user_corrections", {}))

    cursor.execute("""
        INSERT INTO complaints (
            complaint_id, user_name, whatsapp_number, issue_type, title,
            description, severity, public_safety_risk, suggested_department,
            area, city, landmark, additional_details, image_path,
            ai_analysis, user_corrections, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Reported', ?, ?)
    """, (
        data["complaint_id"],
        data["user_name"],
        data["whatsapp_number"],
        data["issue_type"],
        data["title"],
        data.get("description", ""),
        data.get("severity", "Medium"),
        data.get("public_safety_risk", ""),
        data.get("suggested_department", "Public Works"),
        data["area"],
        data["city"],
        data.get("landmark", ""),
        data.get("additional_details", ""),
        data.get("image_path", ""),
        ai_json,
        corrections_json,
        now,
        now
    ))

    conn.commit()
    conn.close()
    return data["complaint_id"]


def get_complaint(complaint_id: str, db_path: str = DEFAULT_DB_PATH) -> Optional[Dict[str, Any]]:
    """Retrieve full details of a specific complaint."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM complaints WHERE complaint_id = ?", (complaint_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    item = dict(row)
    try:
        item["ai_analysis"] = json.loads(item["ai_analysis"]) if item.get("ai_analysis") else {}
    except Exception:
        item["ai_analysis"] = {}

    try:
        item["user_corrections"] = json.loads(item["user_corrections"]) if item.get("user_corrections") else {}
    except Exception:
        item["user_corrections"] = {}

    return item


def get_all_complaints(
    filters: Optional[Dict[str, str]] = None,
    search_query: Optional[str] = None,
    db_path: str = DEFAULT_DB_PATH
) -> List[Dict[str, Any]]:
    """Retrieve all complaints with optional filtering and text search."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    query = "SELECT * FROM complaints WHERE 1=1"
    params: List[Any] = []

    if filters:
        if filters.get("issue_type"):
            query += " AND issue_type = ?"
            params.append(filters["issue_type"])
        if filters.get("severity"):
            query += " AND severity = ?"
            params.append(filters["severity"])
        if filters.get("status"):
            query += " AND status = ?"
            params.append(filters["status"])
        if filters.get("department"):
            query += " AND suggested_department = ?"
            params.append(filters["department"])
        if filters.get("area"):
            query += " AND LOWER(area) LIKE ?"
            params.append(f"%{filters['area'].lower()}%")

    if search_query and search_query.strip():
        term = f"%{search_query.strip().lower()}%"
        query += " AND (LOWER(complaint_id) LIKE ? OR LOWER(title) LIKE ? OR LOWER(area) LIKE ? OR LOWER(city) LIKE ?)"
        params.extend([term, term, term, term])

    query += " ORDER BY id DESC"

    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    results = []
    for r in rows:
        item = dict(r)
        try:
            item["ai_analysis"] = json.loads(item["ai_analysis"]) if item.get("ai_analysis") else {}
        except Exception:
            item["ai_analysis"] = {}
        try:
            item["user_corrections"] = json.loads(item["user_corrections"]) if item.get("user_corrections") else {}
        except Exception:
            item["user_corrections"] = {}
        results.append(item)

    return results


def get_user_complaints(whatsapp_number: str, db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    """Get all complaints filed by a particular citizen's WhatsApp number."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM complaints WHERE whatsapp_number = ? ORDER BY id DESC", (whatsapp_number,))
    rows = cursor.fetchall()
    conn.close()

    results = []
    for r in rows:
        item = dict(r)
        try:
            item["ai_analysis"] = json.loads(item["ai_analysis"]) if item.get("ai_analysis") else {}
        except Exception:
            item["ai_analysis"] = {}
        try:
            item["user_corrections"] = json.loads(item["user_corrections"]) if item.get("user_corrections") else {}
        except Exception:
            item["user_corrections"] = {}
        results.append(item)
    return results


def update_complaint_status(
    complaint_id: str,
    new_status: str,
    department: Optional[str] = None,
    db_path: str = DEFAULT_DB_PATH
) -> bool:
    """Update status and optionally assigned department of a complaint."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    now = datetime.datetime.now().isoformat()

    if department:
        cursor.execute("""
            UPDATE complaints
            SET status = ?, suggested_department = ?, updated_at = ?
            WHERE complaint_id = ?
        """, (new_status, department, now, complaint_id))
    else:
        cursor.execute("""
            UPDATE complaints
            SET status = ?, updated_at = ?
            WHERE complaint_id = ?
        """, (new_status, now, complaint_id))

    conn.commit()
    affected = cursor.rowcount
    conn.close()
    return affected > 0


def add_resolution_proof(
    complaint_id: str,
    resolution_notes: str,
    resolution_image_path: Optional[str] = None,
    db_path: str = DEFAULT_DB_PATH
) -> bool:
    """Mark a complaint as Resolved with resolution proof image and notes."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    now = datetime.datetime.now().isoformat()

    cursor.execute("""
        UPDATE complaints
        SET status = 'Resolved',
            resolution_notes = ?,
            resolution_image_path = COALESCE(?, resolution_image_path),
            resolved_at = ?,
            updated_at = ?
        WHERE complaint_id = ?
    """, (resolution_notes, resolution_image_path, now, now, complaint_id))

    conn.commit()
    affected = cursor.rowcount
    conn.close()
    return affected > 0


def find_possible_duplicates(
    issue_type: str,
    area: str,
    city: str,
    days_window: int = 14,
    db_path: str = DEFAULT_DB_PATH
) -> List[Dict[str, Any]]:
    """
    Search for recent complaints with the same issue type in the same area/city
    to detect duplicate reports before user submission.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    query = """
        SELECT * FROM complaints
        WHERE LOWER(issue_type) = LOWER(?)
          AND LOWER(city) = LOWER(?)
          AND (LOWER(area) LIKE ? OR ? LIKE '%' || LOWER(area) || '%')
          AND status != 'Rejected'
        ORDER BY id DESC LIMIT 5
    """
    cursor.execute(query, (issue_type, city, f"%{area.lower()}%", area.lower()))
    rows = cursor.fetchall()
    conn.close()

    results = []
    for r in rows:
        results.append(dict(r))
    return results


def add_chat_message(
    complaint_id: str,
    role: str,
    message: str,
    db_path: str = DEFAULT_DB_PATH
) -> None:
    """Persist a chat message under a specific complaint."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cursor.execute("""
        INSERT INTO chat_messages (complaint_id, role, message, timestamp)
        VALUES (?, ?, ?, ?)
    """, (complaint_id, role, message, now))
    conn.commit()
    conn.close()


def get_chat_messages(complaint_id: str, db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    """Retrieve chat history for a complaint in chronological order."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT role, message, timestamp
        FROM chat_messages
        WHERE complaint_id = ?
        ORDER BY id ASC
    """, (complaint_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_complaint_stats(db_path: str = DEFAULT_DB_PATH) -> Dict[str, int]:
    """Calculate real-time counts from the database."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM complaints")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM complaints WHERE status NOT IN ('Resolved', 'Rejected')")
    open_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM complaints WHERE severity IN ('High', 'Critical')")
    high_critical = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM complaints WHERE status = 'Resolved'")
    resolved = cursor.fetchone()[0]

    conn.close()

    return {
        "total": total,
        "open": open_count,
        "high_critical": high_critical,
        "resolved": resolved
    }
