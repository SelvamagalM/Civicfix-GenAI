import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// In-memory persistent database for web runtime
interface ComplaintRecord {
  id: number;
  complaint_id: string;
  user_name: string;
  whatsapp_number: string;
  issue_type: string;
  title: string;
  description: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  public_safety_risk: string;
  suggested_department: string;
  area: string;
  city: string;
  landmark: string;
  additional_details?: string;
  image_data?: string;
  ai_analysis?: any;
  user_corrections?: any;
  status: 'Reported' | 'Under Review' | 'Assigned' | 'In Progress' | 'Resolved' | 'Rejected';
  resolution_notes?: string;
  resolution_image_data?: string;
  resolved_at?: string;
  created_at: string;
  updated_at: string;
}

interface ChatMessage {
  id: number;
  complaint_id: string;
  role: 'user' | 'assistant';
  message: string;
  timestamp: string;
}

// Initial sample complaints for real immediate inspection if desired, or starts fresh
let complaints: ComplaintRecord[] = [
  {
    id: 1,
    complaint_id: 'CF-2026-0001',
    user_name: 'Malarkodi C',
    whatsapp_number: '+919360492738',
    issue_type: 'Pothole',
    title: 'Severe crater on arterial roadway',
    description: 'Deep road cavity approximately 1.2m across near the bus stop curb causing vehicles to brake abruptly.',
    severity: 'High',
    public_safety_risk: 'High risk of two-wheeler skids and suspension damage at night.',
    suggested_department: 'Public Works & Road Maintenance',
    area: 'Indiranagar 100ft Road',
    city: 'Bengaluru',
    landmark: 'Opposite Metro Pillar 84',
    additional_details: 'Rainwater fills the hole making it completely invisible after dark.',
    image_data: '',
    status: 'In Progress',
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 4).toISOString()
  },
  {
    id: 2,
    complaint_id: 'CF-2026-0002',
    user_name: 'Malarkodi C',
    whatsapp_number: '+919360492738',
    issue_type: 'Broken Streetlight',
    title: 'Non-functioning sodium lamp at pedestrian crossing',
    description: 'Streetlight pole #42 has been completely dark for over a week.',
    severity: 'Medium',
    public_safety_risk: 'Pedestrians crossing during evening rush hour have near zero visibility.',
    suggested_department: 'Municipal Electrical Dept',
    area: 'Koramangala 4th Block',
    city: 'Bengaluru',
    landmark: 'Near Wipro Park Signal',
    status: 'Resolved',
    resolution_notes: 'Bulb replaced and fixture re-wired by field team on duty.',
    resolved_at: new Date(Date.now() - 3600000 * 12).toISOString(),
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 12).toISOString()
  },
  {
    id: 3,
    complaint_id: 'CF-2026-0003',
    user_name: 'Malarkodi C',
    whatsapp_number: '+919360492738',
    issue_type: 'Garbage / Waste',
    title: 'Overflowing commercial waste dump near market',
    description: 'Large commercial garbage container overflowing onto pedestrian sidewalk for 4 days, emitting foul odor.',
    severity: 'Critical',
    public_safety_risk: 'Health hazard and obstruction of public sidewalk leading to street vendors.',
    suggested_department: 'Solid Waste Management',
    area: 'Commercial Street Junction',
    city: 'Bengaluru',
    landmark: 'Behind Clock Tower',
    additional_details: 'Stray animals scattering waste across the road.',
    image_data: '',
    status: 'Reported',
    created_at: new Date(Date.now() - 3600000 * 8).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 8).toISOString()
  },
  {
    id: 4,
    complaint_id: 'CF-2026-0004',
    user_name: 'Arun Kumar',
    whatsapp_number: '+919876543210',
    issue_type: 'Drainage Problem',
    title: 'Broken stormwater drain cover slab',
    description: 'Concrete slab over open drain cracked and partially collapsed under foot traffic.',
    severity: 'High',
    public_safety_risk: 'Immediate fall hazard for children and elderly pedestrians.',
    suggested_department: 'Stormwater & Drainage Division',
    area: 'Jayanagar 4th Block',
    city: 'Bengaluru',
    landmark: 'Near Complex Gate 2',
    status: 'Under Review',
    created_at: new Date(Date.now() - 86400000 * 1).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 2).toISOString()
  }
];

let chatMessages: ChatMessage[] = [
  {
    id: 1,
    complaint_id: 'CF-2026-0001',
    role: 'user',
    message: 'Why is this classified as High severity?',
    timestamp: new Date(Date.now() - 3600000 * 5).toISOString()
  },
  {
    id: 2,
    complaint_id: 'CF-2026-0001',
    role: 'assistant',
    message: 'This complaint is marked as High severity because the pothole is located directly in the vehicular driving lane of an arterial road (100ft Road) with sharp jagged edges, creating an imminent collision and skid risk for two-wheelers.',
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString()
  }
];

let nextComplaintSeq = 5;

// Initialize Google GenAI
function getGenAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const CIVIC_ANALYSIS_PROMPT = `You are CivicFix AI, a specialized municipal computer vision analyst.
Your mission is to inspect citizen-submitted photographs of public spaces and convert genuine civic hazards and infrastructure damage into structured, factual reports.

### STRICT OPERATIONAL RULES:
1. FACTUAL ACCURACY ONLY: Rely EXCLUSIVELY on visual evidence visible in the image.
2. DO NOT INVENT or hallucinate:
   - GPS coordinates or exact street addresses
   - Government policies, municipality bylaws, or statutory deadlines
   - Official department tracking numbers or internal ticketing codes
   - Resolution timelines or promised completion dates
3. If the image is not a civic/public infrastructure issue (e.g. a selfie, household pet, indoor food, commercial product, scenic nature with no damage):
   - Set "is_civic_issue": false
   - Explain clearly in "description" why it cannot be classified as a public civic problem.
4. "severity" MUST strictly be one of: "Low", "Medium", "High", "Critical".
5. "issue_type" must belong to one of these standard categories or "Other Civic Issue":
   - "Pothole"
   - "Garbage / Waste"
   - "Water Leakage"
   - "Broken Streetlight"
   - "Damaged Road"
   - "Drainage Problem"
   - "Open Manhole"
   - "Traffic Hazard"
   - "Public Infrastructure Damage"
   - "Other Civic Issue"
6. "confidence" must be a float between 0.0 and 1.0.

### OUTPUT FORMAT:
Respond with valid JSON conforming to:
{
    "is_civic_issue": true,
    "issue_type": "Pothole",
    "title": "Severe pothole on asphalt roadway",
    "description": "Visible crater on the asphalt driving lane measuring approximately 1 meter wide with jagged edges and loose debris.",
    "severity": "High",
    "public_safety_risk": "Hazard for two-wheelers and vehicular wheel damage, especially during low light.",
    "suggested_department": "Public Works & Road Maintenance",
    "confidence": 0.94,
    "recommended_action": "Cordon off the crater and fill with cold/hot asphalt mix.",
    "missing_information": ["Exact road name or landmark"]
}
`;

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Helper for resilient multi-model fallback (handles 503 spikes gracefully)
  async function generateWithFallback(ai: GoogleGenAI, contents: any, config?: any) {
    const candidateModels = [
      'gemini-flash-latest',
      process.env.MODEL_NAME,
      'gemini-3.1-flash-lite',
      'gemini-3.8-flash'
    ].filter(Boolean) as string[];
    const uniqueModels = Array.from(new Set(candidateModels));

    let lastError: any = null;
    for (const m of uniqueModels) {
      try {
        const response = await ai.models.generateContent({
          model: m,
          contents,
          config
        });
        if (response && response.text) {
          return response;
        }
      } catch (err: any) {
        console.warn(`Model ${m} failed, trying fallback:`, err?.message || err);
        lastError = err;
      }
    }
    throw lastError || new Error('All model fallbacks exhausted.');
  }

  // API 1: Analyze Issue Photo with Gemini Vision
  app.post('/api/analyze-issue', async (req, res) => {
    try {
      const { imageBase64, mimeType } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ error: 'Missing imageBase64 payload.' });
      }

      const ai = getGenAIClient();
      if (!ai) {
        return res.status(500).json({
          error: 'Gemini API key is not configured in environment.',
          is_civic_issue: false
        });
      }

      // Strip data url prefix if present
      const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, '');

      const response = await generateWithFallback(
        ai,
        {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType: mimeType || 'image/jpeg',
              },
            },
            {
              text: 'Examine this civic photo. Detect if it contains a civic hazard or public infrastructure defect and output the structured JSON report.',
            },
          ],
        },
        {
          systemInstruction: CIVIC_ANALYSIS_PROMPT,
          responseMimeType: 'application/json',
          temperature: 0.2,
        }
      );

      const responseText = response.text || '{}';
      let parsed;
      try {
        parsed = JSON.parse(responseText);
      } catch (err) {
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : {};
      }

      res.json(parsed);
    } catch (error: any) {
      console.error('Error analyzing image:', error);
      res.status(500).json({
        error: error.message || 'Failed to analyze image with Gemini Vision.',
        is_civic_issue: false
      });
    }
  });

  // API 2: AI Complaint Chat Assistant
  app.post('/api/complaint-chat', async (req, res) => {
    try {
      const { complaintContext, chatHistory, userMessage } = req.body;
      if (!complaintContext || !userMessage) {
        return res.status(400).json({ error: 'Missing complaint context or user message.' });
      }

      const ai = getGenAIClient();
      if (!ai) {
        return res.json({ reply: 'AI Assistant is currently unavailable (Gemini API key not configured).' });
      }

      const historyFormatted = (chatHistory || []).map((m: any) =>
        `${m.role === 'user' ? 'Citizen' : 'Assistant'}: ${m.message}`
      ).join('\n');

      const prompt = `
COMPLAINT RECORD:
- Complaint ID: ${complaintContext.complaint_id}
- Issue: ${complaintContext.issue_type} - ${complaintContext.title}
- Description: ${complaintContext.description}
- Severity: ${complaintContext.severity}
- Safety Risk: ${complaintContext.public_safety_risk}
- Department: ${complaintContext.suggested_department}
- Location: ${complaintContext.area}, ${complaintContext.city} (Landmark: ${complaintContext.landmark || 'None'})
- Status: ${complaintContext.status}
- Resolution Notes: ${complaintContext.resolution_notes || 'Pending resolution'}

CONVERSATION HISTORY:
${historyFormatted}

Citizen asks: "${userMessage}"

You are the CivicFix AI Assistant. Answer factually based ONLY on the complaint record above. Do not fabricate municipal bylaws or deadlines. Keep the tone professional, concise, and helpful.`;

      const response = await generateWithFallback(
        ai,
        prompt,
        {
          temperature: 0.3,
        }
      );

      res.json({ reply: response.text || 'I could not generate a response.' });
    } catch (error: any) {
      console.error('Error in complaint chat:', error);
      res.status(500).json({ error: error.message || 'Chat generation failed.' });
    }
  });

  // API 3: Duplicate Check
  app.post('/api/check-duplicate', async (req, res) => {
    try {
      const { issue_type, area, city, title } = req.body;
      const candidates = complaints.filter(
        c => c.city.toLowerCase() === (city || '').toLowerCase() &&
             c.issue_type.toLowerCase() === (issue_type || '').toLowerCase() &&
             (c.area.toLowerCase().includes((area || '').toLowerCase()) ||
              (area || '').toLowerCase().includes(c.area.toLowerCase())) &&
             c.status !== 'Rejected'
      );

      if (candidates.length === 0) {
        return res.json({ is_probable_duplicate: false, rationale: 'No matching complaints found in this locality.' });
      }

      const matched = candidates[0];
      res.json({
        is_probable_duplicate: true,
        matched_complaint_id: matched.complaint_id,
        matched_title: matched.title,
        matched_area: matched.area,
        rationale: `Found an existing '${matched.issue_type}' complaint (${matched.complaint_id}) filed in ${matched.area}.`
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // API 4: Twilio WhatsApp Dispatch & Direct WhatsApp Fallback
  app.post('/api/send-whatsapp', async (req, res) => {
    try {
      const { to_number, user_name, summary } = req.body;

      if (!to_number || typeof to_number !== 'string' || !to_number.trim()) {
        return res.json({
          success: false,
          configured: true,
          message: 'Please provide a recipient phone number with country code (e.g. +919876543210).'
        });
      }

      // Format recipient
      let rawDigits = to_number.replace(/[\s\-\(\)]/g, '');
      if (!rawDigits.startsWith('+')) {
        rawDigits = '+' + rawDigits;
      }
      const cleanPhone = rawDigits.replace(/^\+/, '');
      const cleanTo = rawDigits.startsWith('whatsapp:') ? rawDigits : `whatsapp:${rawDigits}`;

      const whatsappText = `Hello ${user_name || 'Citizen'},\n\nHere is your official CivicFix municipal complaint update:\n\n${summary}`;
      const waDirectUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(whatsappText)}`;

      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;
      const fromNumber = process.env.TWILIO_WHATSAPP_FROM || 'whatsapp:+14155238886';

      if (!accountSid || !authToken) {
        return res.json({
          success: false,
          configured: false,
          waDirectUrl,
          message: 'Twilio credentials not configured in environment. You can use Direct WhatsApp below.'
        });
      }

      let cleanFrom = fromNumber;
      if (!cleanFrom.startsWith('whatsapp:')) cleanFrom = 'whatsapp:' + cleanFrom;

      // Twilio API basic auth request
      const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
      const authHeader = 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64');

      const contentSid = process.env.TWILIO_CONTENT_SID;
      const bodyParams = new URLSearchParams();
      bodyParams.append('From', cleanFrom);
      bodyParams.append('To', cleanTo);

      if (contentSid && contentSid.startsWith('HX')) {
        bodyParams.append('ContentSid', contentSid);
        bodyParams.append('ContentVariables', JSON.stringify({
          '1': user_name || 'Citizen',
          '2': summary.slice(0, 900)
        }));
      } else {
        bodyParams.append('Body', whatsappText);
      }

      const twilioRes = await fetch(twilioUrl, {
        method: 'POST',
        headers: {
          'Authorization': authHeader,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: bodyParams.toString()
      });

      const twilioData = await twilioRes.json();
      if (!twilioRes.ok) {
        let helpfulMessage = twilioData.message || 'Twilio WhatsApp dispatch failed.';
        if (twilioData.code === 21654 || twilioData.message?.includes('ContentSid Required')) {
          helpfulMessage = 'Twilio Trial requires a pre-approved template (ContentSid) for API outbound. You can click below to send directly via WhatsApp with one tap!';
        } else if (twilioData.code === 21608 || twilioData.code === 572002 || (twilioData.message && twilioData.message.includes('verified recipient'))) {
          helpfulMessage = `Recipient ${rawDigits} is not yet verified or joined to Twilio Sandbox. Use the Direct WhatsApp button below to send immediately!`;
        }
        return res.json({
          success: false,
          configured: true,
          waDirectUrl,
          message: helpfulMessage,
          twilioError: twilioData
        });
      }

      res.json({
        success: true,
        configured: true,
        waDirectUrl,
        message: `WhatsApp message sent via Twilio! (SID: ${twilioData.sid})`
      });
    } catch (error: any) {
      console.error('WhatsApp error:', error);
      res.json({
        success: false,
        configured: false,
        message: `WhatsApp dispatch failed: ${error.message || 'Unknown error'}`
      });
    }
  });

  // API 4b: Incoming Twilio WhatsApp Webhook (handles incoming citizen messages & auto-replies)
  app.all(['/api/whatsapp-webhook', '/api/twilio/webhook', '/api/incoming-whatsapp'], async (req, res) => {
    try {
      const from = (req.body?.From || req.query?.From || '') as string;
      const bodyText = (req.body?.Body || req.query?.Body || '') as string;
      const mediaUrl = (req.body?.MediaUrl0 || req.query?.MediaUrl0 || '') as string;
      const phoneDigits = from.replace(/whatsapp:/, '').trim();

      console.log(`Incoming WhatsApp message from ${from}: "${bodyText}" (media: ${mediaUrl})`);

      let replyMsg = `Hello! CivicFix recorded your message from ${phoneDigits || 'citizen'}.`;

      if (bodyText.toLowerCase().includes('join')) {
        replyMsg = `✅ Welcome to CivicFix Citizen Reporting! Send your civic issue description or photo here, or use the online portal to file an official municipal complaint.`;
      } else if (bodyText.trim() || mediaUrl) {
        const newComplaintId = `CF-2026-${String(nextComplaintSeq++).padStart(4, '0')}`;
        const newRecord: ComplaintRecord = {
          id: complaints.length + 1,
          complaint_id: newComplaintId,
          user_name: `Citizen (${phoneDigits.slice(-4) || 'WhatsApp'})`,
          whatsapp_number: phoneDigits || '+919360492738',
          issue_type: bodyText.toLowerCase().includes('pothole') ? 'Pothole' :
                      bodyText.toLowerCase().includes('garbage') ? 'Garbage / Waste' :
                      bodyText.toLowerCase().includes('water') ? 'Water Leakage' :
                      bodyText.toLowerCase().includes('light') ? 'Broken Streetlight' : 'Other Civic Issue',
          title: bodyText ? bodyText.slice(0, 45) : 'WhatsApp Civic Photo Report',
          description: bodyText || 'Report received via WhatsApp submission.',
          severity: 'Medium',
          public_safety_risk: 'Reported via citizen mobile WhatsApp channel.',
          suggested_department: 'Municipal Operations',
          area: 'Reported via WhatsApp',
          city: 'City Central',
          landmark: '',
          image_data: mediaUrl || '',
          status: 'Reported',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        complaints.unshift(newRecord);

        replyMsg = `✅ CivicFix Complaint Registered!\nTracking ID: ${newComplaintId}\nIssue: ${newRecord.issue_type}\nStatus: Reported to City Authorities.`;
      }

      // Valid TwiML text/xml (resolves Twilio error 12300)
      const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>${replyMsg}</Message>
</Response>`;
      res.set('Content-Type', 'text/xml');
      res.status(200).send(twiml);
    } catch (err: any) {
      console.error('Webhook error:', err);
      res.set('Content-Type', 'text/xml');
      res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?><Response><Message>CivicFix received your update.</Message></Response>`);
    }
  });

  // Complaints CRUD
  app.get('/api/complaints', (req, res) => {
    res.json(complaints);
  });

  app.get('/api/complaints/:id', (req, res) => {
    const found = complaints.find(c => c.complaint_id === req.params.id);
    if (!found) return res.status(404).json({ error: 'Complaint not found.' });
    res.json(found);
  });

  app.post('/api/complaints', (req, res) => {
    const data = req.body;
    const year = new Date().getFullYear();
    const cid = `CF-${year}-${String(nextComplaintSeq).padStart(4, '0')}`;
    nextComplaintSeq++;

    const newRecord: ComplaintRecord = {
      id: complaints.length + 1,
      complaint_id: cid,
      user_name: data.user_name || 'Anonymous Citizen',
      whatsapp_number: data.whatsapp_number || '',
      issue_type: data.issue_type || 'Other Civic Issue',
      title: data.title || 'Civic Issue',
      description: data.description || '',
      severity: data.severity || 'Medium',
      public_safety_risk: data.public_safety_risk || '',
      suggested_department: data.suggested_department || 'Public Works',
      area: data.area || '',
      city: data.city || '',
      landmark: data.landmark || '',
      additional_details: data.additional_details || '',
      image_data: data.image_data || '',
      ai_analysis: data.ai_analysis || {},
      user_corrections: data.user_corrections || {},
      status: 'Reported',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    complaints.unshift(newRecord);
    res.status(201).json(newRecord);
  });

  app.patch('/api/complaints/:id', (req, res) => {
    const cid = req.params.id;
    const idx = complaints.findIndex(c => c.complaint_id === cid);
    if (idx === -1) return res.status(404).json({ error: 'Complaint not found' });

    const existing = complaints[idx];
    const { status, suggested_department, resolution_notes, resolution_image_data } = req.body;

    if (status) existing.status = status;
    if (suggested_department) existing.suggested_department = suggested_department;
    if (resolution_notes) existing.resolution_notes = resolution_notes;
    if (resolution_image_data) existing.resolution_image_data = resolution_image_data;
    if (status === 'Resolved' && !existing.resolved_at) {
      existing.resolved_at = new Date().toISOString();
    }
    existing.updated_at = new Date().toISOString();

    res.json(existing);
  });

  // Chat messages endpoints
  app.get('/api/chat/:complaint_id', (req, res) => {
    const msgs = chatMessages.filter(m => m.complaint_id === req.params.complaint_id);
    res.json(msgs);
  });

  app.post('/api/chat/:complaint_id', (req, res) => {
    const { role, message } = req.body;
    const newMsg: ChatMessage = {
      id: chatMessages.length + 1,
      complaint_id: req.params.complaint_id,
      role: role || 'user',
      message: message || '',
      timestamp: new Date().toISOString()
    };
    chatMessages.push(newMsg);
    res.status(201).json(newMsg);
  });

  // Stats endpoint
  app.get('/api/stats', (req, res) => {
    const total = complaints.length;
    const open = complaints.filter(c => !['Resolved', 'Rejected'].includes(c.status)).length;
    const high_critical = complaints.filter(c => ['High', 'Critical'].includes(c.severity)).length;
    const resolved = complaints.filter(c => c.status === 'Resolved').length;

    res.json({ total, open, high_critical, resolved });
  });

  // In development, mount Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CivicFix server listening on port ${PORT}`);
  });
}

startServer();
