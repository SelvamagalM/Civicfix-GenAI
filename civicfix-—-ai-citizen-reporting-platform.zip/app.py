"""
app.py - CivicFix Streamlit Citizen Reporting & Resolution Application
=======================================================================
Transforms civic issue photographs into actionable municipal complaints
using Gemini Vision, structured editing, duplicate detection, SQLite
persistence, complaint-aware conversational AI, and WhatsApp distribution.
"""

import os
import json
import streamlit as st
from PIL import Image
import datetime

# Internal modular services
import database as db
import ai_service as ai
import whatsapp_service as wa
import utils

# Ensure working directories exist
UPLOADS_REPORTS = os.path.join(os.path.dirname(__file__), "uploads", "reports")
UPLOADS_RESOLUTIONS = os.path.join(os.path.dirname(__file__), "uploads", "resolutions")
os.makedirs(UPLOADS_REPORTS, exist_ok=True)
os.makedirs(UPLOADS_RESOLUTIONS, exist_ok=True)

# Initialize database schema on startup
db.init_database()

# Page Configuration
st.set_page_config(
    page_title="CivicFix — AI Citizen Reporting Platform",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Civic-Tech CSS
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    
    .main-header {
        background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
        color: white;
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 2rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
    
    .metric-card {
        background-color: white;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 1.25rem;
        text-align: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .badge-pill {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.825rem;
        font-weight: 600;
        margin-right: 0.5rem;
    }
    
    .complaint-card {
        background-color: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 1.25rem;
        margin-bottom: 1rem;
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .complaint-card:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .stButton>button {
        border-radius: 8px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)

# Session State Initialization
if "user_name" not in st.session_state:
    st.session_state["user_name"] = ""
if "whatsapp_number" not in st.session_state:
    st.session_state["whatsapp_number"] = ""
if "onboarded" not in st.session_state:
    st.session_state["onboarded"] = False
if "current_analysis" not in st.session_state:
    st.session_state["current_analysis"] = None
if "uploaded_image_bytes" not in st.session_state:
    st.session_state["uploaded_image_bytes"] = None
if "uploaded_image_name" not in st.session_state:
    st.session_state["uploaded_image_name"] = None
if "duplicate_warning" not in st.session_state:
    st.session_state["duplicate_warning"] = None
if "admin_authenticated" not in st.session_state:
    st.session_state["admin_authenticated"] = False
if "active_complaint_id" not in st.session_state:
    st.session_state["active_complaint_id"] = None


# Helper: Check Admin Password
def check_admin_password(password: str) -> bool:
    admin_pw = ""
    try:
        if "ADMIN_PASSWORD" in st.secrets:
            admin_pw = str(st.secrets["ADMIN_PASSWORD"])
    except Exception:
        pass
    if not admin_pw:
        admin_pw = os.environ.get("ADMIN_PASSWORD", "civicadmin2026")
    return password == admin_pw


# Sidebar Navigation & Onboarding Profile
with st.sidebar:
    st.markdown("## 🏛️ **CivicFix**")
    st.caption("AI-Powered Citizen Reporting Platform")
    st.divider()

    # User Onboarding Card
    if not st.session_state["onboarded"]:
        st.subheader("👤 Citizen Profile")
        with st.form("onboarding_form"):
            name_input = st.text_input("Your Full Name", value=st.session_state["user_name"], placeholder="e.g. Malarkodi C")
            phone_input = st.text_input("WhatsApp Number", value=st.session_state["whatsapp_number"], placeholder="e.g. +14155552671")
            save_btn = st.form_submit_button("Set Profile", use_container_width=True)
            if save_btn:
                if name_input.strip() and utils.validate_whatsapp_number(phone_input):
                    st.session_state["user_name"] = name_input.strip()
                    st.session_state["whatsapp_number"] = phone_input.strip()
                    st.session_state["onboarded"] = True
                    st.success("Profile saved!")
                    st.rerun()
                else:
                    st.error("Please enter a valid name and phone number with country code.")
    else:
        st.markdown(f"**Citizen:** {st.session_state['user_name']}")
        st.caption(f"📱 WhatsApp: `{st.session_state['whatsapp_number']}`")
        if st.button("Edit Profile", key="btn_edit_profile"):
            st.session_state["onboarded"] = False
            st.rerun()

    st.divider()

    nav_options = [
        "🏠 Home",
        "📸 Report Issue",
        "📋 My Reports",
        "🗺️ Reported Issues",
        "💬 Complaint Assistant",
        "🔐 Admin"
    ]
    selected_nav = st.radio("Navigation", nav_options, index=0)

    st.divider()
    # Live stats snippet
    stats = db.get_complaint_stats()
    st.caption(f"📊 **Live Overview**")
    st.caption(f"• Total Complaints: **{stats['total']}**")
    st.caption(f"• Active / Open: **{stats['open']}**")
    st.caption(f"• Resolved Proofs: **{stats['resolved']}**")


# ==============================================================================
# 1. 🏠 HOME VIEW
# ==============================================================================
if selected_nav == "🏠 Home":
    st.markdown("""
    <div class="main-header">
        <h1 style="margin:0; font-size: 2.2rem; font-weight: 700;">CivicFix</h1>
        <p style="margin: 0.5rem 0 0 0; font-size: 1.15rem; color: #94A3B8;">
            Turn civic problems into actionable complaints with Google Gemini AI.
        </p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric(label="Total Filed", value=stats["total"])
    with col2:
        st.metric(label="In Resolution", value=stats["open"])
    with col3:
        st.metric(label="High / Critical", value=stats["high_critical"])
    with col4:
        st.metric(label="Successfully Resolved", value=stats["resolved"])

    st.markdown("### How CivicFix Works")
    step_col1, step_col2, step_col3, step_col4, step_col5 = st.columns(5)
    with step_col1:
        st.markdown("#### 1. 📸 Capture")
        st.write("Snap a clear photo of any pothole, waste spill, or infrastructure hazard.")
    with step_col2:
        st.markdown("#### 2. 🤖 Analyze")
        st.write("Gemini Vision pinpoints the hazard type, estimated severity, and safety risks.")
    with step_col3:
        st.markdown("#### 3. 📝 Report")
        st.write("Review, edit the report, set locality markers, and obtain a unique complaint ID.")
    with step_col4:
        st.markdown("#### 4. 📲 Track & Chat")
        st.write("Ask the AI assistant questions and dispatch summaries via Twilio WhatsApp.")
    with step_col5:
        st.markdown("#### 5. ✅ Resolve")
        st.write("Authorities update progress and attach verified before/after resolution evidence.")

    st.markdown("---")
    cta_col1, cta_col2 = st.columns([1, 3])
    with cta_col1:
        if st.button("🚀 Report a Civic Issue Now", type="primary", use_container_width=True):
            st.session_state["selected_nav_override"] = "📸 Report Issue"
            # Switch radio via rerun or prompt user
            st.info("Select **📸 Report Issue** in the sidebar to begin!")


# ==============================================================================
# 2. 📸 REPORT ISSUE WORKFLOW
# ==============================================================================
elif selected_nav == "📸 Report Issue":
    st.markdown("## 📸 Report a Civic Issue")
    st.write("Upload a photograph of public infrastructure defect or sanitation hazard. Gemini AI will analyze the image and generate a structured municipal complaint.")

    # Check onboarding
    if not st.session_state["user_name"] or not st.session_state["whatsapp_number"]:
        st.warning("⚠️ Please provide your name and WhatsApp number in the sidebar profile before submitting complaints.")

    uploaded_file = st.file_uploader(
        "Upload Issue Photo (JPG, PNG, JPEG, WEBP)",
        type=["jpg", "jpeg", "png", "webp"],
        help="Make sure the civic defect is clearly visible."
    )

    if uploaded_file is not None:
        file_bytes = uploaded_file.getvalue()
        st.session["uploaded_image_bytes"] = file_bytes if hasattr(st, "session") else None
        st.session_state["uploaded_image_bytes"] = file_bytes
        st.session_state["uploaded_image_name"] = uploaded_file.name

        img_col1, img_col2 = st.columns([1, 2])
        with img_col1:
            st.image(uploaded_file, caption="Uploaded Photo Preview", use_container_width=True)
            if st.button("🔍 Analyze Issue with Gemini", type="primary", use_container_width=True):
                with st.spinner("Gemini Vision is inspecting photo for civic hazards..."):
                    mime = uploaded_file.type or "image/jpeg"
                    analysis_result = ai.analyze_civic_image(file_bytes, mime_type=mime)
                    st.session_state["current_analysis"] = analysis_result
                    st.session_state["duplicate_warning"] = None

        with img_col2:
            analysis = st.session_state.get("current_analysis")
            if analysis:
                if "error" in analysis:
                    st.error(f"❌ {analysis['error']}")
                elif not analysis.get("is_civic_issue", False):
                    st.warning("⚠️ **No Civic Issue Detected**")
                    st.write(analysis.get("description", "The image does not show a public hazard or municipal problem."))
                    st.info("Please upload a clearer photograph showing public roads, sanitation, streetlights, drainage, or civic utilities.")
                else:
                    st.success("✅ **Civic Issue Detected by Gemini Vision**")
                    sev = analysis.get("severity", "Medium")
                    s_badge = utils.get_severity_badge(sev)
                    
                    st.markdown(f"""
                    **Issue Detected:** `{analysis.get('issue_type')}`  
                    **Title:** {analysis.get('title')}  
                    **Severity:** <span style="background-color:{s_badge['bg']}; color:{s_badge['hex']}; padding:3px 8px; border-radius:4px; font-weight:bold;">{s_badge['icon']} {sev}</span> (Confidence: {int(analysis.get('confidence', 0.8) * 100)}%)  
                    **Department:** {analysis.get('suggested_department')}  
                    **Safety Risk:** {analysis.get('public_safety_risk')}  
                    **Recommended Action:** {analysis.get('recommended_action')}  
                    """, unsafe_allow_html=True)
                    st.caption("ℹ️ *AI-generated information — please review, edit, and add location details below before submitting.*")

    # Editable Submission Form
    analysis = st.session_state.get("current_analysis")
    if analysis and analysis.get("is_civic_issue", False):
        st.markdown("---")
        st.subheader("📝 Review & Edit Complaint")
        st.info("💡 **Citizen priority rule:** You can correct any AI-detected field below. Your edits will be saved as the official record.")

        STANDARD_CATEGORIES = [
            "Pothole", "Garbage / Waste", "Water Leakage", "Broken Streetlight",
            "Damaged Road", "Drainage Problem", "Open Manhole", "Traffic Hazard",
            "Public Infrastructure Damage", "Other Civic Issue"
        ]
        detected_type = analysis.get("issue_type", "Pothole")
        cat_index = STANDARD_CATEGORIES.index(detected_type) if detected_type in STANDARD_CATEGORIES else len(STANDARD_CATEGORIES) - 1

        with st.form("complaint_submission_form"):
            c_col1, c_col2 = st.columns(2)
            with c_col1:
                edit_issue_type = st.selectbox("Issue Type", STANDARD_CATEGORIES, index=cat_index)
                edit_title = st.text_input("Complaint Title", value=analysis.get("title", ""))
                edit_severity = st.selectbox("Severity", ["Low", "Medium", "High", "Critical"], index=["Low", "Medium", "High", "Critical"].index(analysis.get("severity", "Medium")))
                edit_dept = st.text_input("Suggested Department", value=analysis.get("suggested_department", "Public Works"))
            with c_col2:
                edit_area = st.text_input("Area / Locality *", placeholder="e.g. 5th Main, Indiranagar")
                edit_city = st.text_input("City *", placeholder="e.g. Bengaluru")
                edit_landmark = st.text_input("Landmark / Nearby Pole or Shop", placeholder="e.g. Opposite Metro Pillar 142")
                edit_safety = st.text_input("Public Safety Risk", value=analysis.get("public_safety_risk", ""))

            edit_desc = st.text_area("Detailed Description", value=analysis.get("description", ""), height=100)
            edit_additional = st.text_area("Additional Details / Specific Instructions", placeholder="e.g. Water accumulates heavily during evening showers.", height=70)

            # Duplicate Check Trigger
            check_dup_btn = st.form_submit_button("🔍 Check for Duplicate Reports & Validate")
            submit_btn = st.form_submit_button("🚀 Confirm & Submit Complaint", type="primary")

            if check_dup_btn or submit_btn:
                valid, msg = utils.validate_complaint_input(edit_title, edit_issue_type, edit_area, edit_city)
                if not valid:
                    st.error(f"Validation Error: {msg}")
                else:
                    # Search database for duplicates
                    nearby = db.find_possible_duplicates(edit_issue_type, edit_area, edit_city)
                    if nearby:
                        dup_result = ai.check_ai_duplicate({
                            "issue_type": edit_issue_type,
                            "title": edit_title,
                            "description": edit_desc,
                            "area": edit_area,
                            "city": edit_city,
                            "landmark": edit_landmark
                        }, nearby)
                        if dup_result.get("is_probable_duplicate"):
                            st.session_state["duplicate_warning"] = {
                                "matched": dup_result.get("matched_complaint_id"),
                                "rationale": dup_result.get("rationale")
                            }

            if submit_btn:
                valid, msg = utils.validate_complaint_input(edit_title, edit_issue_type, edit_area, edit_city)
                if not valid:
                    st.error(f"Cannot submit: {msg}")
                elif not st.session_state["user_name"]:
                    st.error("Please provide your name in the sidebar profile before submitting.")
                else:
                    # Save image to disk
                    saved_img_path = ""
                    if st.session_state.get("uploaded_image_bytes"):
                        safe_name = utils.sanitize_filename(st.session_state.get("uploaded_image_name", "complaint.jpg"))
                        dest_path = os.path.join(UPLOADS_REPORTS, safe_name)
                        with open(dest_path, "wb") as f:
                            f.write(st.session_state["uploaded_image_bytes"])
                        saved_img_path = dest_path

                    # Generate dynamic ID
                    offset = db.get_next_complaint_offset()
                    cid = utils.generate_complaint_id(count_offset=offset)

                    user_corrections = {
                        "issue_type": edit_issue_type,
                        "title": edit_title,
                        "description": edit_desc,
                        "severity": edit_severity,
                        "suggested_department": edit_dept,
                        "area": edit_area,
                        "city": edit_city,
                        "landmark": edit_landmark,
                        "additional_details": edit_additional
                    }

                    complaint_record = {
                        "complaint_id": cid,
                        "user_name": st.session_state["user_name"],
                        "whatsapp_number": st.session_state["whatsapp_number"],
                        "issue_type": edit_issue_type,
                        "title": edit_title,
                        "description": edit_desc,
                        "severity": edit_severity,
                        "public_safety_risk": edit_safety,
                        "suggested_department": edit_dept,
                        "area": edit_area,
                        "city": edit_city,
                        "landmark": edit_landmark,
                        "additional_details": edit_additional,
                        "image_path": saved_img_path,
                        "ai_analysis": analysis,
                        "user_corrections": user_corrections
                    }

                    # Persist to database
                    db.create_complaint(complaint_record)

                    # Reset temporary state
                    st.session_state["current_analysis"] = None
                    st.session_state["uploaded_image_bytes"] = None
                    st.session_state["active_complaint_id"] = cid

                    st.balloons()
                    st.success(f"🎉 Complaint **{cid}** submitted successfully!")
                    st.info("You can track progress in **📋 My Reports** or converse with the AI in **💬 Complaint Assistant**.")

        # Show duplicate warning if present
        if st.session_state.get("duplicate_warning"):
            dup_info = st.session_state["duplicate_warning"]
            st.warning(f"⚠️ **Possible duplicate complaint detected ({dup_info.get('matched')})**")
            st.write(dup_info.get("rationale"))
            st.caption("You may still proceed to submit if this is a distinct or recurring issue.")


# ==============================================================================
# 3. 📋 MY REPORTS
# ==============================================================================
elif selected_nav == "📋 My Reports":
    st.markdown("## 📋 My Filed Reports")
    phone = st.session_state.get("whatsapp_number", "")
    
    if not phone:
        st.info("Enter your WhatsApp number in the sidebar profile to view your submitted reports.")
    else:
        user_reports = db.get_user_complaints(phone)
        if not user_reports:
            st.info("You haven't filed any complaints with this WhatsApp number yet.")
        else:
            st.write(f"Showing **{len(user_reports)}** complaint(s) linked to `{phone}`:")
            for report in user_reports:
                cid = report["complaint_id"]
                sev_badge = utils.get_severity_badge(report.get("severity", "Medium"))
                st_badge = utils.get_status_badge(report.get("status", "Reported"))

                with st.expander(f"{st_badge['icon']} **{cid}** — {report.get('title')} ({report.get('status')})", expanded=False):
                    d_col1, d_col2 = st.columns([1, 2])
                    with d_col1:
                        if report.get("image_path") and os.path.exists(report["image_path"]):
                            st.image(report["image_path"], caption="Reported Photo", use_container_width=True)
                        else:
                            st.caption("No image on file")
                    with d_col2:
                        st.markdown(f"""
                        **Issue:** `{report.get('issue_type')}`  
                        **Location:** {report.get('area')}, {report.get('city')} (Landmark: {report.get('landmark', 'N/A')})  
                        **Severity:** <span style="background-color:{sev_badge['bg']}; color:{sev_badge['hex']}; padding:2px 8px; border-radius:4px; font-weight:bold;">{sev_badge['icon']} {report.get('severity')}</span>  
                        **Department:** {report.get('suggested_department')}  
                        **Public Safety Risk:** {report.get('public_safety_risk')}  
                        **Description:** {report.get('description')}  
                        **Reported Date:** {utils.format_timestamp(report.get('created_at'))}  
                        """, unsafe_allow_html=True)

                        # Resolution proof if resolved
                        if report.get("status") == "Resolved":
                            st.success("✅ **Resolution Complete**")
                            st.write(f"**Resolution Note:** {report.get('resolution_notes')}")
                            st.caption(f"Resolved On: {utils.format_timestamp(report.get('resolved_at'))}")
                            if report.get("resolution_image_path") and os.path.exists(report["resolution_image_path"]):
                                st.image(report["resolution_image_path"], caption="Resolution Proof (After)", width=250)

                    # Quick Actions
                    act_col1, act_col2 = st.columns(2)
                    with act_col1:
                        if st.button(f"💬 Chat with AI regarding {cid}", key=f"chat_{cid}"):
                            st.session_state["active_complaint_id"] = cid
                            st.info("Switch to **💬 Complaint Assistant** to continue conversation.")
                    with act_col2:
                        if st.button(f"📲 Generate WhatsApp Summary for {cid}", key=f"sum_{cid}"):
                            summary_text = ai.generate_complaint_summary(report)
                            st.code(summary_text, language="markdown")
                            if wa.is_twilio_configured():
                                success, msg = wa.send_whatsapp(phone, report.get("user_name", "Citizen"), summary_text)
                                if success:
                                    st.success(msg)
                                else:
                                    st.error(msg)
                            else:
                                st.warning("WhatsApp integration is not configured yet. Add Twilio credentials in Streamlit secrets.")


# ==============================================================================
# 4. 🗺️ REPORTED ISSUES (PUBLIC DASHBOARD)
# ==============================================================================
elif selected_nav == "🗺️ Reported Issues":
    st.markdown("## 🗺️ Public Issues Dashboard")
    st.write("Browse all citizen-reported civic defects, ongoing municipal workflows, and verified resolutions.")

    # Top Filters
    f_col1, f_col2, f_col3, f_col4 = st.columns(4)
    with f_col1:
        filter_issue = st.selectbox("Filter Issue Type", ["All"] + [
            "Pothole", "Garbage / Waste", "Water Leakage", "Broken Streetlight",
            "Damaged Road", "Drainage Problem", "Open Manhole", "Traffic Hazard",
            "Public Infrastructure Damage", "Other Civic Issue"
        ])
    with f_col2:
        filter_sev = st.selectbox("Filter Severity", ["All", "Critical", "High", "Medium", "Low"])
    with f_col3:
        filter_status = st.selectbox("Filter Status", ["All", "Reported", "Under Review", "Assigned", "In Progress", "Resolved", "Rejected"])
    with f_col4:
        search_kw = st.text_input("Search ID, Title, Locality", placeholder="e.g. Indiranagar or CF-2026")

    # Construct Filter Map
    f_map = {}
    if filter_issue != "All":
        f_map["issue_type"] = filter_issue
    if filter_sev != "All":
        f_map["severity"] = filter_sev
    if filter_status != "All":
        f_map["status"] = filter_status

    all_complaints = db.get_all_complaints(filters=f_map, search_query=search_kw)

    st.caption(f"Showing **{len(all_complaints)}** matching complaint record(s):")

    if not all_complaints:
        st.info("No complaints found matching the selected criteria.")
    else:
        for c in all_complaints:
            s_badge = utils.get_severity_badge(c.get("severity", "Medium"))
            st_badge = utils.get_status_badge(c.get("status", "Reported"))

            with st.container():
                st.markdown(f"""
                <div class="complaint-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                        <div>
                            <span style="font-weight:700; font-size:1.1rem; color:#0F172A;">{c.get('complaint_id')}</span>
                            <span class="badge-pill" style="background-color:#E2E8F0; color:#334155; margin-left:8px;">{c.get('issue_type')}</span>
                        </div>
                        <div>
                            <span class="badge-pill" style="background-color:{s_badge['bg']}; color:{s_badge['hex']};">{s_badge['icon']} {c.get('severity')}</span>
                            <span class="badge-pill" style="background-color:{st_badge['bg']}; color:{st_badge['hex']};">{st_badge['icon']} {c.get('status')}</span>
                        </div>
                    </div>
                    <div style="font-size:1rem; font-weight:600; color:#1E293B; margin-bottom:0.25rem;">{c.get('title')}</div>
                    <div style="font-size:0.875rem; color:#64748B; margin-bottom:0.5rem;">📍 {c.get('area')}, {c.get('city')} {f"(Near {c.get('landmark')})" if c.get('landmark') else ""} • 🏛️ {c.get('suggested_department')} • 🕒 {utils.format_timestamp(c.get('created_at'))}</div>
                    <div style="font-size:0.9rem; color:#334155;">{c.get('description')}</div>
                </div>
                """, unsafe_allow_html=True)


# ==============================================================================
# 5. 💬 COMPLAINT ASSISTANT
# ==============================================================================
elif selected_nav == "💬 Complaint Assistant":
    st.markdown("## 💬 AI Complaint Assistant")
    st.write("An intelligent assistant grounded strictly in your complaint details to answer questions, recommend next steps, or compose concise summaries.")

    all_complaints = db.get_all_complaints()
    if not all_complaints:
        st.info("No complaints found in the database. Please file a complaint first under **📸 Report Issue**.")
    else:
        # Selection of active complaint
        complaint_options = [c["complaint_id"] for c in all_complaints]
        default_index = 0
        if st.session_state.get("active_complaint_id") in complaint_options:
            default_index = complaint_options.index(st.session_state["active_complaint_id"])

        selected_cid = st.selectbox("Select Complaint to Discuss", complaint_options, index=default_index)
        st.session_state["active_complaint_id"] = selected_cid

        complaint = db.get_complaint(selected_cid)

        # Overview Card of Active Complaint
        with st.expander("📌 View Complaint Details Context", expanded=True):
            o_col1, o_col2 = st.columns([1, 2])
            with o_col1:
                if complaint.get("image_path") and os.path.exists(complaint["image_path"]):
                    st.image(complaint["image_path"], caption=f"Evidence: {selected_cid}", use_container_width=True)
                else:
                    st.caption("No image on file")
            with o_col2:
                st.markdown(f"""
                **ID:** `{complaint.get('complaint_id')}` | **Status:** `{complaint.get('status')}`  
                **Issue:** {complaint.get('issue_type')} — **{complaint.get('title')}**  
                **Severity:** {complaint.get('severity')}  
                **Department:** {complaint.get('suggested_department')}  
                **Location:** {complaint.get('area')}, {complaint.get('city')} (Landmark: {complaint.get('landmark', 'N/A')})  
                **Description:** {complaint.get('description')}  
                """)

        # Quick Actions: Summary & WhatsApp
        q_col1, q_col2 = st.columns(2)
        with q_col1:
            if st.button("📄 Generate Complaint Summary"):
                summary_text = ai.generate_complaint_summary(complaint)
                st.code(summary_text, language="markdown")
                st.session_state["latest_summary"] = summary_text
        with q_col2:
            if st.button("📲 Send to WhatsApp"):
                summary_text = st.session_state.get("latest_summary") or ai.generate_complaint_summary(complaint)
                target_phone = complaint.get("whatsapp_number") or st.session_state.get("whatsapp_number")
                if not target_phone:
                    st.error("No recipient WhatsApp phone number on file.")
                else:
                    success, msg = wa.send_whatsapp(target_phone, complaint.get("user_name", "Citizen"), summary_text)
                    if success:
                        st.success(msg)
                    else:
                        st.warning(msg)

        st.divider()

        # Chat History Display
        st.markdown("### Conversation")
        chat_history = db.get_chat_messages(selected_cid)
        for msg in chat_history:
            with st.chat_message(msg["role"]):
                st.write(msg["message"])
                st.caption(utils.format_timestamp(msg.get("timestamp")))

        # Preset Prompt Buttons
        st.caption("Quick Questions:")
        p_col1, p_col2, p_col3, p_col4 = st.columns(4)
        preset_prompt = None
        if p_col1.button("Why is this severity chosen?"):
            preset_prompt = "Why is this severity level assigned to my issue?"
        if p_col2.button("Why this department?"):
            preset_prompt = "Why did you choose this suggested department?"
        if p_col3.button("Make this complaint shorter"):
            preset_prompt = "Please rephrase this complaint into a concise 2-sentence municipal memo."
        if p_col4.button("What should I do next?"):
            preset_prompt = "What should I do next to ensure this issue gets resolved quickly?"

        # Chat Input
        user_input = st.chat_input("Ask a question about this complaint...")
        prompt_to_send = user_input or preset_prompt

        if prompt_to_send:
            # Append user message
            db.add_chat_message(selected_cid, "user", prompt_to_send)
            with st.chat_message("user"):
                st.write(prompt_to_send)

            with st.chat_message("assistant"):
                with st.spinner("CivicFix AI is thinking..."):
                    updated_history = db.get_chat_messages(selected_cid)
                    ai_reply = ai.complaint_chat_response(complaint, updated_history, prompt_to_send)
                    st.write(ai_reply)
                    db.add_chat_message(selected_cid, "assistant", ai_reply)
            st.rerun()


# ==============================================================================
# 6. 🔐 ADMIN / MODERATOR PORTAL
# ==============================================================================
elif selected_nav == "🔐 Admin":
    st.markdown("## 🔐 Municipal Authority & Admin Portal")
    st.write("Manage incoming complaints, update investigation stages, assign field departments, and upload after-resolution evidence.")

    if not st.session_state["admin_authenticated"]:
        with st.form("admin_login_form"):
            st.subheader("Admin Authentication")
            pw_input = st.text_input("Enter Admin Password", type="password")
            login_btn = st.form_submit_button("Authenticate", type="primary")
            if login_btn:
                if check_admin_password(pw_input):
                    st.session_state["admin_authenticated"] = True
                    st.success("Authentication successful!")
                    st.rerun()
                else:
                    st.error("Invalid administrator password.")
    else:
        st.success("🔓 Authenticated as Municipal Administrator")
        if st.button("Log Out", key="admin_logout"):
            st.session_state["admin_authenticated"] = False
            st.rerun()

        st.divider()

        all_complaints = db.get_all_complaints()
        if not all_complaints:
            st.info("No complaints found in system.")
        else:
            complaint_opts = [f"{c['complaint_id']} — {c.get('title')} ({c.get('status')})" for c in all_complaints]
            selected_comp_idx = st.selectbox("Select Complaint to Moderate", range(len(complaint_opts)), format_func=lambda i: complaint_opts[i])
            active_admin_c = all_complaints[selected_comp_idx]
            admin_cid = active_admin_c["complaint_id"]

            st.markdown(f"### Managing Complaint `{admin_cid}`")

            col_a, col_b = st.columns(2)
            with col_a:
                st.markdown("#### Original Complaint")
                if active_admin_c.get("image_path") and os.path.exists(active_admin_c["image_path"]):
                    st.image(active_admin_c["image_path"], caption="BEFORE: Citizen Photo", use_container_width=True)
                st.write(f"**Citizen:** {active_admin_c.get('user_name')} ({active_admin_c.get('whatsapp_number')})")
                st.write(f"**Issue:** {active_admin_c.get('issue_type')}")
                st.write(f"**Location:** {active_admin_c.get('area')}, {active_admin_c.get('city')}")
                st.write(f"**Description:** {active_admin_c.get('description')}")

            with col_b:
                st.markdown("#### Update Status & Resolution")
                STATUS_LIST = ["Reported", "Under Review", "Assigned", "In Progress", "Resolved", "Rejected"]
                curr_status_idx = STATUS_LIST.index(active_admin_c.get("status", "Reported"))

                with st.form("admin_action_form"):
                    new_status = st.selectbox("Update Status", STATUS_LIST, index=curr_status_idx)
                    new_dept = st.text_input("Assigned Department", value=active_admin_c.get("suggested_department", "Public Works"))

                    resolution_file = None
                    resolution_notes = ""
                    if new_status == "Resolved":
                        st.markdown("##### 📸 Resolution Proof (Required for Closure)")
                        resolution_file = st.file_uploader("Upload After-Resolution Image", type=["jpg", "jpeg", "png", "webp"])
                        resolution_notes = st.text_area("Resolution Details / Field Officer Notes", value=active_admin_c.get("resolution_notes", ""), placeholder="e.g. Crater filled with standard bitumen cold-mix and rolled.")

                    update_btn = st.form_submit_button("Save Updates", type="primary")

                    if update_btn:
                        if new_status == "Resolved":
                            res_img_path = None
                            if resolution_file:
                                safe_res_name = f"res_{utils.sanitize_filename(resolution_file.name)}"
                                res_dest = os.path.join(UPLOADS_RESOLUTIONS, safe_res_name)
                                with open(res_dest, "wb") as rf:
                                    rf.write(resolution_file.getvalue())
                                res_img_path = res_dest
                            
                            db.add_resolution_proof(admin_cid, resolution_notes, res_img_path)
                            db.update_complaint_status(admin_cid, "Resolved", new_dept)
                            st.success(f"Complaint {admin_cid} marked as Resolved with proof!")
                        else:
                            db.update_complaint_status(admin_cid, new_status, new_dept)
                            st.success(f"Status for {admin_cid} updated to {new_status}!")
                        st.rerun()

            # Before / After Comparison Display if Resolved
            if active_admin_c.get("status") == "Resolved":
                st.divider()
                st.markdown("### 🔍 Verified Resolution Inspection")
                cmp_1, cmp_2 = st.columns(2)
                with cmp_1:
                    st.markdown("**BEFORE (Reported Hazard)**")
                    if active_admin_c.get("image_path") and os.path.exists(active_admin_c["image_path"]):
                        st.image(active_admin_c["image_path"], use_container_width=True)
                with cmp_2:
                    st.markdown("**AFTER (Field Resolution)**")
                    if active_admin_c.get("resolution_image_path") and os.path.exists(active_admin_c["resolution_image_path"]):
                        st.image(active_admin_c["resolution_image_path"], use_container_width=True)
                    else:
                        st.caption("No resolution image uploaded.")
                st.info(f"**Resolution Note:** {active_admin_c.get('resolution_notes') or 'Work completed by field team.'}")
                st.caption(f"Resolved Date: {utils.format_timestamp(active_admin_c.get('resolved_at'))}")
