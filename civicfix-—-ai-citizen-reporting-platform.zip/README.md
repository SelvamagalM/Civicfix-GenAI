# CivicFix — AI-Powered Citizen Reporting Platform

> Turn citizen photos of civic defects into actionable municipal complaints with Google Gemini AI, persistent tracking, conversational assistance, and WhatsApp distribution.

---

## 📌 Problem Statement

Every day, citizens encounter broken streetlights, hazardous potholes, overflowing waste bins, open manholes, and damaged public utilities. Traditional municipal reporting processes fail because:
1. **Friction in Reporting**: Citizens are forced to navigate complicated departmental categories, technical terminology, and lengthy forms.
2. **Ambiguous Descriptions**: Complaints lack standardized severity metrics, hazard assessments, or clear municipal routing information.
3. **Information Black Holes**: Citizens rarely receive transparent tracking, immediate context-grounded answers, or verifiable proof of resolution.

---

## 💡 Solution

**CivicFix** adapts the **MacroSnap** workshop pattern (User → Input → Gemini Vision → Structured Output → Contextual Chat → Summary → WhatsApp Action) into a robust civic-tech application.

A citizen simply snaps a photograph of any public infrastructure problem. Google Gemini Vision inspects the photo, detects the exact hazard category, estimates safety risks and severity, and drafts a structured complaint. The citizen reviews, corrects, and adds locality markers. Once submitted, CivicFix stores the complaint in SQLite, offers an interactive Gemini Chat assistant grounded in the complaint record, generates a standardized complaint summary, and dispatches it via Twilio WhatsApp. Municipal administrators can review incoming complaints, update investigative workflows, and upload photographic proof of resolution (Before & After).

---

## 🚀 Key Features

- **📸 One-Shot Photo Ingestion**: Accepts JPG, PNG, WEBP uploads of civic issues.
- **🤖 Gemini Vision Hazard Analysis**: Zero-shot detection of 10+ civic categories (`Pothole`, `Garbage / Waste`, `Water Leakage`, `Broken Streetlight`, `Damaged Road`, `Drainage Problem`, `Open Manhole`, `Traffic Hazard`, `Public Infrastructure Damage`, etc.).
- **⚖️ Citizen Override Priority**: AI serves as an assistant; citizens can freely correct issue types, severity, descriptions, and department assignments.
- **🔍 Smart Duplicate Detection**: Proactively cross-references new complaints against nearby records in the same locality to prevent duplicate municipal dispatch.
- **🆔 Dynamic Complaint ID**: Auto-generates sequential, traceable complaint IDs (e.g., `CF-2026-0001`).
- **💬 Grounded AI Complaint Assistant**: Conversational Gemini Chat providing answers strictly grounded in the filed complaint (e.g., *"Why was this classified as High severity?"*, *"Make this complaint shorter"*).
- **📲 WhatsApp Integration via Twilio**: Transmits standardized complaint summaries directly to the citizen's WhatsApp number.
- **🗺️ Public Issues Dashboard**: Real-time filterable directory (by Issue Type, Severity, Department, Status) with full-text search.
- **🔐 Protected Admin Portal**: Password-guarded municipal dashboard with status workflow management (`Reported` → `Under Review` → `Assigned` → `In Progress` → `Resolved` → `Rejected`) and resolution proof image uploads.
- **📸 Before & After Verification**: Clear photographic comparison between the initial hazard and the completed repair.

---

## 🏗️ Architecture & Workshop Pattern

```
                       CITIZEN / USER
                             │
                  [Upload Civic Issue Photo]
                             ▼
              Google Gemini Vision (google-genai)
                             │
              [Structured JSON Issue Analysis]
                             ▼
             Citizen Review & Location Input Form
                             │
                 [Duplicate Detection Check]
                             ▼
               SQLite Persistent Store (civicfix.db)
                ├── Complaints & Status Workflow
                ├── Chat Conversation History
                └── Before/After Image References
                             │
          ┌──────────────────┴──────────────────┐
          ▼                                     ▼
Gemini Chat Assistant                 Twilio WhatsApp API
(Context-Grounded Q&A)              (Complaint Summaries)
          │                                     │
          └──────────────────┬──────────────────┘
                             ▼
              Admin Moderation & Resolution
```

---

## 🛠️ Tech Stack

- **Frontend / Framework**: Streamlit (Python)
- **AI / Multimodal LLM**: Google Gemini (`google-genai` SDK, `gemini-3.8-flash`)
- **Database**: SQLite3 (Transactional, parameterized queries, relational indices)
- **Messaging**: Twilio WhatsApp REST API
- **Image Processing**: Pillow (`PIL`)
- **Hosting / Deployment Target**: Streamlit Community Cloud / Docker

---

## 📁 Project Structure

```
civicfix/
│
├── app.py                     # Main Streamlit application and page router
├── prompts.py                 # Structured system instructions and prompts
├── ai_service.py              # Gemini Vision, Chat, Summary, and Duplicate detection
├── database.py                # SQLite persistence, schema initialization, and queries
├── whatsapp_service.py        # Twilio WhatsApp REST client and message dispatcher
├── utils.py                   # Complaint ID generator, file sanitizer, validators
├── requirements.txt           # Minimal, pinned Python dependencies
├── README.md                  # Complete architectural documentation and setup guide
├── .gitignore                 # Exclusion rules for secrets, DB, and uploads
│
├── data/
│   └── civicfix.db            # SQLite database file (created automatically)
│
├── uploads/
│   ├── reports/               # Citizen uploaded issue photographs
│   └── resolutions/           # Municipal after-resolution proof photographs
│
└── .streamlit/
    └── secrets.toml.example   # Template for environment secrets
```

---

## 🤖 How Gemini AI is Used

1. **Multimodal Hazard Identification (`ai_service.py:analyze_civic_image`)**:
   - The citizen's photograph is passed as an inline binary payload to Gemini Vision.
   - Using `CIVIC_ANALYSIS_SYSTEM_PROMPT`, Gemini generates structured JSON with issue category, title, description, severity (`Low`, `Medium`, `High`, `Critical`), safety risk, suggested municipal department, and confidence score.
   - Non-civic images (selfies, household items, nature photos) are gracefully identified with `is_civic_issue: false`.

2. **Duplicate Detection Reasoning (`ai_service.py:check_ai_duplicate`)**:
   - Compares new submissions against nearby active complaints to prevent redundant municipal dispatch.

3. **Complaint-Aware Chat Assistant (`ai_service.py:complaint_chat_response`)**:
   - Provides an interactive Q&A assistant where the full complaint record is supplied as contextual grounding.
   - Accurately answers questions on rationale, drafting concise summaries, or advising next steps without inventing municipal facts.

4. **Complaint Summarization (`ai_service.py:generate_complaint_summary`)**:
   - Structures a concise, standardized dispatch memo for WhatsApp and municipal ticketing systems.

---

## 📲 How WhatsApp (Twilio) is Used

- Implements the Twilio WhatsApp REST API via `twilio.rest.Client`.
- Transmits an official, formatted summary directly to the citizen's WhatsApp number (`whatsapp:+<E.164>`).
- If Twilio credentials are not yet configured, the system **never crashes**; it displays an informative guidance message explaining how to add credentials in `.streamlit/secrets.toml`.

---

## ⚙️ Installation & Local Setup

### 1. Prerequisites
- Python 3.10 or higher
- Git

### 2. Clone Repository & Setup Virtual Environment
```bash
git clone https://github.com/your-username/civicfix.git
cd civicfix

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Linux/macOS:
source venv/bin/activate
# On Windows:
venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure Secrets
Create `.streamlit/secrets.toml` by copying the example template:
```bash
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Edit `.streamlit/secrets.toml`:
```toml
# Google Gemini API
GEMINI_API_KEY = "AIzaSy..."
MODEL_NAME = "gemini-3.8-flash"

# Twilio WhatsApp Integration (Optional for local testing)
TWILIO_ACCOUNT_SID = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
TWILIO_AUTH_TOKEN = "your_twilio_auth_token"
TWILIO_WHATSAPP_FROM = "whatsapp:+14155238886"
TWILIO_CONTENT_SID = ""

# Admin Authentication
ADMIN_PASSWORD = "your_secure_admin_password"
```

### 5. Run CivicFix Locally
```bash
streamlit run app.py
```
CivicFix will start on `http://localhost:8501`.

---

## 🚀 Deployment to Streamlit Community Cloud

1. **Push to GitHub**:
   Ensure `.streamlit/secrets.toml` is **NOT** committed (verified by `.gitignore`).
   ```bash
   git add .
   git commit -m "feat: CivicFix AI citizen reporting platform"
   git push origin main
   ```

2. **Deploy on Streamlit Cloud**:
   - Log in to [share.streamlit.io](https://share.streamlit.io/).
   - Click **New App** and select your GitHub repository, branch `main`, and main file `app.py`.
   - Under **Advanced Settings > Secrets**, paste the contents of your `secrets.toml`:
     ```toml
     GEMINI_API_KEY = "AIzaSy..."
     MODEL_NAME = "gemini-3.8-flash"
     TWILIO_ACCOUNT_SID = "AC..."
     TWILIO_AUTH_TOKEN = "..."
     TWILIO_WHATSAPP_FROM = "whatsapp:+14155238886"
     ADMIN_PASSWORD = "..."
     ```
   - Click **Deploy!**

---

## 🧪 Testing Scenarios

1. **Pothole Detection**: Upload a road pothole image. Gemini identifies issue as `Pothole`, estimates severity as `High`, suggests `Public Works & Road Maintenance`, and detects vehicle hazard risk.
2. **Garbage Spill**: Upload overflowing municipal bin. Gemini identifies `Garbage / Waste`, assigns `Medium` severity, and routes to `Sanitation & Waste Management`.
3. **Invalid Image**: Upload an unrelated picture (e.g. food or coffee cup). CivicFix flags `No Civic Issue Detected` and prompts for a genuine infrastructure photograph.
4. **Offline / Missing Twilio**: Triggering WhatsApp when credentials are unset produces a friendly instruction badge without halting app execution.

---

## 🔒 Security Best Practices

- **Zero Hardcoded Secrets**: All API tokens and passwords read from `st.secrets` or environment variables.
- **Path Traversal Protection**: Uploaded filenames are sanitized and assigned random UUID prefixes.
- **SQL Injection Prevention**: All SQLite queries use strict parameterized bindings (`?`).
- **Prompt Injection Defense**: Citizen inputs are clearly delineated from system instructions.

---

## 📄 License

CivicFix is open-source under the MIT License.
