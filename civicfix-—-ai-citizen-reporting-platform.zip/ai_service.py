"""
ai_service.py - Google Gemini AI Services for CivicFix
======================================================
Handles Gemini Vision image analysis, structured report generation,
complaint-aware conversational assistant, standardized summary creation,
and AI-based duplicate detection.
"""

import os
import json
from typing import Dict, Any, List, Optional
from prompts import (
    CIVIC_ANALYSIS_SYSTEM_PROMPT,
    COMPLAINT_CHAT_SYSTEM_PROMPT,
    COMPLAINT_SUMMARY_PROMPT,
    DUPLICATE_DETECTION_PROMPT
)
from utils import safe_parse_json

# Conditional Streamlit caching for reusable client
try:
    import streamlit as st
    HAS_STREAMLIT = True
except ImportError:
    HAS_STREAMLIT = False


def _get_api_key() -> str:
    """Retrieve Gemini API Key from Streamlit secrets or OS environment."""
    if HAS_STREAMLIT:
        try:
            if "GEMINI_API_KEY" in st.secrets:
                return str(st.secrets["GEMINI_API_KEY"])
        except Exception:
            pass
    return os.environ.get("GEMINI_API_KEY", "")


def _get_model_name() -> str:
    """Retrieve preferred model name, defaulting to gemini-3.8-flash."""
    if HAS_STREAMLIT:
        try:
            if "MODEL_NAME" in st.secrets:
                return str(st.secrets["MODEL_NAME"])
        except Exception:
            pass
    return os.environ.get("MODEL_NAME", "gemini-3.8-flash")


def _init_gemini_client():
    """Initialize modern Google GenAI Client."""
    api_key = _get_api_key()
    if not api_key:
        return None
    try:
        from google import genai
        return genai.Client(api_key=api_key)
    except Exception as e:
        print(f"Error initializing GenAI Client: {e}")
        return None


# Cache client in Streamlit runtime to avoid re-creation on every rerun
if HAS_STREAMLIT:
    get_gemini_client = st.cache_resource(_init_gemini_client)
else:
    _cached_client = None
    def get_gemini_client():
        global _cached_client
        if _cached_client is None:
            _cached_client = _init_gemini_client()
        return _cached_client


def analyze_civic_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> Dict[str, Any]:
    """
    Analyze an uploaded image of a civic/infrastructure issue using Gemini Vision.
    Returns structured JSON with issue type, severity, hazard assessment, and confidence.
    """
    client = get_gemini_client()
    if not client:
        return {
            "error": "Gemini API key is not configured. Please add GEMINI_API_KEY to .streamlit/secrets.toml or system environment variables.",
            "is_civic_issue": False
        }

    from google.genai import types

    model_name = _get_model_name()

    try:
        image_part = types.Part.from_bytes(data=image_bytes, mime_type=mime_type)
        user_prompt = "Examine this civic photo. Detect if it contains a civic hazard or public infrastructure defect and output the structured JSON report."

        response = client.models.generate_content(
            model=model_name,
            contents=[image_part, user_prompt],
            config=types.GenerateContentConfig(
                system_instruction=CIVIC_ANALYSIS_SYSTEM_PROMPT,
                response_mime_type="application/json",
                temperature=0.2,
            )
        )

        raw_text = response.text or ""
        parsed = safe_parse_json(raw_text)

        if not parsed:
            return {
                "error": "Could not parse structured response from AI vision model.",
                "raw_response": raw_text,
                "is_civic_issue": False
            }

        # Normalize required keys and fallback defaults
        parsed["is_civic_issue"] = bool(parsed.get("is_civic_issue", False))
        parsed["issue_type"] = parsed.get("issue_type") or "Other Civic Issue"
        parsed["title"] = parsed.get("title") or "Reported Civic Hazard"
        parsed["description"] = parsed.get("description") or "Visual defect observed in uploaded photograph."
        
        # Enforce severity enum
        sev = str(parsed.get("severity", "Medium")).capitalize()
        if sev not in ["Low", "Medium", "High", "Critical"]:
            sev = "Medium"
        parsed["severity"] = sev

        parsed["public_safety_risk"] = parsed.get("public_safety_risk") or "General public awareness advised."
        parsed["suggested_department"] = parsed.get("suggested_department") or "Public Works & Road Maintenance"
        
        try:
            conf = float(parsed.get("confidence", 0.8))
            parsed["confidence"] = max(0.0, min(1.0, round(conf, 2)))
        except (ValueError, TypeError):
            parsed["confidence"] = 0.85

        parsed["recommended_action"] = parsed.get("recommended_action") or "Field inspection and containment."
        if not isinstance(parsed.get("missing_information"), list):
            parsed["missing_information"] = []

        return parsed

    except Exception as e:
        return {
            "error": f"Gemini Vision API error: {str(e)}",
            "is_civic_issue": False
        }


def complaint_chat_response(
    complaint_context: Dict[str, Any],
    chat_history: List[Dict[str, str]],
    user_question: str
) -> str:
    """
    Context-aware AI assistant answering citizen questions about their complaint.
    Strictly grounds answers in the provided complaint record.
    """
    client = get_gemini_client()
    if not client:
        return "AI Assistant is unavailable because GEMINI_API_KEY is not configured."

    from google.genai import types

    model_name = _get_model_name()

    context_str = f"""
CURRENT COMPLAINT RECORD:
- Complaint ID: {complaint_context.get('complaint_id')}
- Status: {complaint_context.get('status')}
- Citizen Name: {complaint_context.get('user_name')}
- Issue Type: {complaint_context.get('issue_type')}
- Title: {complaint_context.get('title')}
- Description: {complaint_context.get('description')}
- Severity: {complaint_context.get('severity')}
- Public Safety Risk: {complaint_context.get('public_safety_risk')}
- Assigned/Suggested Department: {complaint_context.get('suggested_department')}
- Location: {complaint_context.get('area')}, {complaint_context.get('city')} (Landmark: {complaint_context.get('landmark', 'Not specified')})
- Additional Notes: {complaint_context.get('additional_details', 'None')}
- Resolution Notes: {complaint_context.get('resolution_notes', 'Pending resolution')}
"""

    history_lines = []
    for msg in chat_history[-6:]:
        role = "Citizen" if msg["role"] == "user" else "Assistant"
        history_lines.append(f"{role}: {msg['message']}")

    prompt = f"""{context_str}

RECENT CONVERSATION HISTORY:
{chr(10).join(history_lines)}

Citizen asks: "{user_question}"

Provide a concise, helpful, and factually grounded response based ONLY on the complaint record above."""

    try:
        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=COMPLAINT_CHAT_SYSTEM_PROMPT,
                temperature=0.3,
            )
        )
        return response.text or "I'm sorry, I could not generate a response at this time."
    except Exception as e:
        return f"Error communicating with AI Assistant: {str(e)}"


def generate_complaint_summary(complaint: Dict[str, Any]) -> str:
    """
    Generate a standardized civic complaint summary string suitable for
    official escalation or WhatsApp messaging without inventing facts.
    """
    return COMPLAINT_SUMMARY_PROMPT.format(
        complaint_id=complaint.get("complaint_id", "CF-PENDING"),
        issue_type=complaint.get("issue_type", "Civic Issue"),
        title=complaint.get("title", ""),
        area=complaint.get("area", "Unspecified Area"),
        city=complaint.get("city", "Unspecified City"),
        landmark=complaint.get("landmark") or "None specified",
        severity=complaint.get("severity", "Medium"),
        description=complaint.get("description", "No description provided"),
        public_safety_risk=complaint.get("public_safety_risk", "Standard hazard"),
        suggested_department=complaint.get("suggested_department", "Public Works"),
        status=complaint.get("status", "Reported"),
        user_name=complaint.get("user_name", "Concerned Citizen")
    ).strip()


def check_ai_duplicate(
    new_issue: Dict[str, Any],
    candidate_complaints: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Use Gemini reasoning to evaluate whether the new report duplicates an existing report.
    """
    if not candidate_complaints:
        return {"is_probable_duplicate": False, "rationale": "No nearby complaints found."}

    client = get_gemini_client()
    if not client:
        # Fallback to simple rule-based duplicate check
        for c in candidate_complaints:
            if c.get("issue_type", "").lower() == new_issue.get("issue_type", "").lower():
                return {
                    "is_probable_duplicate": True,
                    "matched_complaint_id": c["complaint_id"],
                    "similarity_score": 0.8,
                    "rationale": f"Matching issue type '{c.get('issue_type')}' in same locality ({c.get('area')})."
                }
        return {"is_probable_duplicate": False, "rationale": "No similar complaints detected."}

    from google.genai import types
    model_name = _get_model_name()

    candidates_summary = []
    for c in candidate_complaints[:4]:
        candidates_summary.append({
            "complaint_id": c["complaint_id"],
            "title": c.get("title"),
            "issue_type": c.get("issue_type"),
            "area": c.get("area"),
            "landmark": c.get("landmark"),
            "description": c.get("description", "")[:120]
        })

    prompt = f"""
NEW REPORT TO EVALUATE:
Issue Type: {new_issue.get('issue_type')}
Title: {new_issue.get('title')}
Description: {new_issue.get('description')}
Area: {new_issue.get('area')}
City: {new_issue.get('city')}
Landmark: {new_issue.get('landmark')}

EXISTING CANDIDATE COMPLAINTS:
{json.dumps(candidates_summary, indent=2)}

Determine if the new report is likely the same physical civic issue.
"""

    try:
        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=DUPLICATE_DETECTION_PROMPT,
                response_mime_type="application/json",
                temperature=0.1
            )
        )
        parsed = safe_parse_json(response.text or "")
        if parsed:
            return parsed
    except Exception as e:
        print(f"Duplicate detection error: {e}")

    return {"is_probable_duplicate": False, "rationale": "Unable to evaluate duplicate AI model."}
